"use strict";
cc._RF.push(module, '64efcEa41pMeL6r2GxQ8w03', 'Standard');
// Script/Standard.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    lb_showInput: cc.Label,
    //输入
    lb_preStep: cc.Label //输出

  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var win = cc.director.getWinSize();
    cc.view.setDesignResolutionSize(win.width, win.height, cc.ResolutionPolicy.EXACT_FIT);
    window.std = this;
    this.lb_showInput.string = '0';
    this.lb_preStep.string = '';
  },
  start: function start() {},
  //按钮点击回调
  btnCallBack: function btnCallBack(sender, str) {
    cal.handleKey(str);
  } // update (dt) {},

});

cc._RF.pop();