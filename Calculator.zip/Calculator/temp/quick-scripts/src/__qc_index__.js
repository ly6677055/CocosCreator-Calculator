
require('./assets/Script/FullScreenAdapter');
require('./assets/Script/Globals');
require('./assets/Script/Standard');
