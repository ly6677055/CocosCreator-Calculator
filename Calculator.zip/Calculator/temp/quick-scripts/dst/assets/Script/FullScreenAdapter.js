
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/FullScreenAdapter.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f91fcEAmNZDeoHbOcnMKaNq', 'FullScreenAdapter');
// Script/FullScreenAdapter.js

"use strict";

//FullScreenAdapter.js
cc.Class({
  "extends": cc.Component,
  properties: {
    bg: cc.Node
  },
  onLoad: function onLoad() {
    var _this = this;

    //监听窗口大小变化时的回调，每次窗口变化都要自动适配
    cc.view.setResizeCallback(function () {
      return _this.screenAdapter();
    });
    this.screenAdapter();
  },

  /**
   * Fit Height 模式：适用于宽大于高的屏幕
   * Fit Width 模式：适用于高大于宽的屏幕
   */
  screenAdapter: function screenAdapter() {
    //当前屏幕分辨率比例
    var screenRatio = cc.winSize.width / cc.winSize.height; //设计稿分辨率比例

    var designRatio = cc.Canvas.instance.designResolution.width / cc.Canvas.instance.designResolution.height;

    if (screenRatio <= 1) {
      //屏幕高度大于或等于宽度,即竖屏
      if (screenRatio <= designRatio) {
        this.setFitWidth();
      } else {
        //此时屏幕比例大于设计比例
        //为了保证纵向的游戏内容不受影响，应该使用 fitHeight 模式
        this.setFitHeight();
      }
    } else {
      //屏幕宽度大于高度,即横屏
      this.setFitHeight();
    }
  },
  setFitWidth: function setFitWidth() {
    cc.Canvas.instance.fitHeight = false;
    cc.Canvas.instance.fitWidth = true;
  },
  setFitHeight: function setFitHeight() {
    cc.Canvas.instance.fitHeight = true;
    cc.Canvas.instance.fitWidth = false;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxGdWxsU2NyZWVuQWRhcHRlci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImJnIiwiTm9kZSIsIm9uTG9hZCIsInZpZXciLCJzZXRSZXNpemVDYWxsYmFjayIsInNjcmVlbkFkYXB0ZXIiLCJzY3JlZW5SYXRpbyIsIndpblNpemUiLCJ3aWR0aCIsImhlaWdodCIsImRlc2lnblJhdGlvIiwiQ2FudmFzIiwiaW5zdGFuY2UiLCJkZXNpZ25SZXNvbHV0aW9uIiwic2V0Rml0V2lkdGgiLCJzZXRGaXRIZWlnaHQiLCJmaXRIZWlnaHQiLCJmaXRXaWR0aCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsRUFBRSxFQUFFSixFQUFFLENBQUNLO0FBREMsR0FIUDtBQU9MQyxFQUFBQSxNQVBLLG9CQU9LO0FBQUE7O0FBQ047QUFDQU4sSUFBQUEsRUFBRSxDQUFDTyxJQUFILENBQVFDLGlCQUFSLENBQTBCO0FBQUEsYUFBTSxLQUFJLENBQUNDLGFBQUwsRUFBTjtBQUFBLEtBQTFCO0FBQ0EsU0FBS0EsYUFBTDtBQUNILEdBWEk7O0FBYUw7QUFDSjtBQUNBO0FBQ0E7QUFDSUEsRUFBQUEsYUFqQkssMkJBaUJXO0FBQ1o7QUFDQSxRQUFJQyxXQUFXLEdBQUdWLEVBQUUsQ0FBQ1csT0FBSCxDQUFXQyxLQUFYLEdBQW1CWixFQUFFLENBQUNXLE9BQUgsQ0FBV0UsTUFBaEQsQ0FGWSxDQUdaOztBQUNBLFFBQUlDLFdBQVcsR0FBR2QsRUFBRSxDQUFDZSxNQUFILENBQVVDLFFBQVYsQ0FBbUJDLGdCQUFuQixDQUFvQ0wsS0FBcEMsR0FBNENaLEVBQUUsQ0FBQ2UsTUFBSCxDQUFVQyxRQUFWLENBQW1CQyxnQkFBbkIsQ0FBb0NKLE1BQWxHOztBQUVBLFFBQUlILFdBQVcsSUFBSSxDQUFuQixFQUFzQjtBQUNsQjtBQUNBLFVBQUlBLFdBQVcsSUFBSUksV0FBbkIsRUFBZ0M7QUFDNUIsYUFBS0ksV0FBTDtBQUNILE9BRkQsTUFFTztBQUNIO0FBQ0E7QUFDQSxhQUFLQyxZQUFMO0FBQ0g7QUFDSixLQVRELE1BU087QUFDSDtBQUNBLFdBQUtBLFlBQUw7QUFDSDtBQUNKLEdBcENJO0FBc0NMRCxFQUFBQSxXQXRDSyx5QkFzQ1M7QUFDVmxCLElBQUFBLEVBQUUsQ0FBQ2UsTUFBSCxDQUFVQyxRQUFWLENBQW1CSSxTQUFuQixHQUErQixLQUEvQjtBQUNBcEIsSUFBQUEsRUFBRSxDQUFDZSxNQUFILENBQVVDLFFBQVYsQ0FBbUJLLFFBQW5CLEdBQThCLElBQTlCO0FBQ0gsR0F6Q0k7QUEyQ0xGLEVBQUFBLFlBM0NLLDBCQTJDVTtBQUNYbkIsSUFBQUEsRUFBRSxDQUFDZSxNQUFILENBQVVDLFFBQVYsQ0FBbUJJLFNBQW5CLEdBQStCLElBQS9CO0FBQ0FwQixJQUFBQSxFQUFFLENBQUNlLE1BQUgsQ0FBVUMsUUFBVixDQUFtQkssUUFBbkIsR0FBOEIsS0FBOUI7QUFDSDtBQTlDSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL0Z1bGxTY3JlZW5BZGFwdGVyLmpzXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgYmc6IGNjLk5vZGVcclxuICAgIH0sXHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICAvL+ebkeWQrOeql+WPo+Wkp+Wwj+WPmOWMluaXtueahOWbnuiwg++8jOavj+asoeeql+WPo+WPmOWMlumDveimgeiHquWKqOmAgumFjVxyXG4gICAgICAgIGNjLnZpZXcuc2V0UmVzaXplQ2FsbGJhY2soKCkgPT4gdGhpcy5zY3JlZW5BZGFwdGVyKCkpO1xyXG4gICAgICAgIHRoaXMuc2NyZWVuQWRhcHRlcigpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvKipcclxuICAgICAqIEZpdCBIZWlnaHQg5qih5byP77ya6YCC55So5LqO5a695aSn5LqO6auY55qE5bGP5bmVXHJcbiAgICAgKiBGaXQgV2lkdGgg5qih5byP77ya6YCC55So5LqO6auY5aSn5LqO5a6955qE5bGP5bmVXHJcbiAgICAgKi9cclxuICAgIHNjcmVlbkFkYXB0ZXIoKSB7XHJcbiAgICAgICAgLy/lvZPliY3lsY/luZXliIbovqjnjofmr5TkvotcclxuICAgICAgICBsZXQgc2NyZWVuUmF0aW8gPSBjYy53aW5TaXplLndpZHRoIC8gY2Mud2luU2l6ZS5oZWlnaHQ7XHJcbiAgICAgICAgLy/orr7orqHnqL/liIbovqjnjofmr5TkvotcclxuICAgICAgICBsZXQgZGVzaWduUmF0aW8gPSBjYy5DYW52YXMuaW5zdGFuY2UuZGVzaWduUmVzb2x1dGlvbi53aWR0aCAvIGNjLkNhbnZhcy5pbnN0YW5jZS5kZXNpZ25SZXNvbHV0aW9uLmhlaWdodDtcclxuXHJcbiAgICAgICAgaWYgKHNjcmVlblJhdGlvIDw9IDEpIHtcclxuICAgICAgICAgICAgLy/lsY/luZXpq5jluqblpKfkuo7miJbnrYnkuo7lrr3luqYs5Y2z56uW5bGPXHJcbiAgICAgICAgICAgIGlmIChzY3JlZW5SYXRpbyA8PSBkZXNpZ25SYXRpbykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZXRGaXRXaWR0aCgpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy/mraTml7blsY/luZXmr5TkvovlpKfkuo7orr7orqHmr5TkvotcclxuICAgICAgICAgICAgICAgIC8v5Li65LqG5L+d6K+B57q15ZCR55qE5ri45oiP5YaF5a655LiN5Y+X5b2x5ZON77yM5bqU6K+l5L2/55SoIGZpdEhlaWdodCDmqKHlvI9cclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0Rml0SGVpZ2h0KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvL+Wxj+W5leWuveW6puWkp+S6jumrmOW6pizljbPmqKrlsY9cclxuICAgICAgICAgICAgdGhpcy5zZXRGaXRIZWlnaHQoKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHNldEZpdFdpZHRoKCkge1xyXG4gICAgICAgIGNjLkNhbnZhcy5pbnN0YW5jZS5maXRIZWlnaHQgPSBmYWxzZTtcclxuICAgICAgICBjYy5DYW52YXMuaW5zdGFuY2UuZml0V2lkdGggPSB0cnVlO1xyXG4gICAgfSxcclxuXHJcbiAgICBzZXRGaXRIZWlnaHQoKSB7XHJcbiAgICAgICAgY2MuQ2FudmFzLmluc3RhbmNlLmZpdEhlaWdodCA9IHRydWU7XHJcbiAgICAgICAgY2MuQ2FudmFzLmluc3RhbmNlLmZpdFdpZHRoID0gZmFsc2U7XHJcbiAgICB9XHJcbn0pOyJdfQ==