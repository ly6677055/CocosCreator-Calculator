
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Standard.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '64efcEa41pMeL6r2GxQ8w03', 'Standard');
// Script/Standard.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    lb_showInput: cc.Label,
    //输入
    lb_preStep: cc.Label //输出

  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var win = cc.director.getWinSize();
    cc.view.setDesignResolutionSize(win.width, win.height, cc.ResolutionPolicy.EXACT_FIT);
    window.std = this;
    this.lb_showInput.string = '0';
    this.lb_preStep.string = '';
  },
  start: function start() {},
  //按钮点击回调
  btnCallBack: function btnCallBack(sender, str) {
    cal.handleKey(str);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxTdGFuZGFyZC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImxiX3Nob3dJbnB1dCIsIkxhYmVsIiwibGJfcHJlU3RlcCIsIm9uTG9hZCIsIndpbiIsImRpcmVjdG9yIiwiZ2V0V2luU2l6ZSIsInZpZXciLCJzZXREZXNpZ25SZXNvbHV0aW9uU2l6ZSIsIndpZHRoIiwiaGVpZ2h0IiwiUmVzb2x1dGlvblBvbGljeSIsIkVYQUNUX0ZJVCIsIndpbmRvdyIsInN0ZCIsInN0cmluZyIsInN0YXJ0IiwiYnRuQ2FsbEJhY2siLCJzZW5kZXIiLCJzdHIiLCJjYWwiLCJoYW5kbGVLZXkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxZQUFZLEVBQUVKLEVBQUUsQ0FBQ0ssS0FEVDtBQUNpRDtBQUN6REMsSUFBQUEsVUFBVSxFQUFFTixFQUFFLENBQUNLLEtBRlAsQ0FFaUQ7O0FBRmpELEdBSFA7QUFRTDtBQUVBRSxFQUFBQSxNQVZLLG9CQVVLO0FBQ04sUUFBSUMsR0FBRyxHQUFHUixFQUFFLENBQUNTLFFBQUgsQ0FBWUMsVUFBWixFQUFWO0FBQ0FWLElBQUFBLEVBQUUsQ0FBQ1csSUFBSCxDQUFRQyx1QkFBUixDQUFnQ0osR0FBRyxDQUFDSyxLQUFwQyxFQUEyQ0wsR0FBRyxDQUFDTSxNQUEvQyxFQUF1RGQsRUFBRSxDQUFDZSxnQkFBSCxDQUFvQkMsU0FBM0U7QUFDQUMsSUFBQUEsTUFBTSxDQUFDQyxHQUFQLEdBQWEsSUFBYjtBQUNBLFNBQUtkLFlBQUwsQ0FBa0JlLE1BQWxCLEdBQTJCLEdBQTNCO0FBQ0EsU0FBS2IsVUFBTCxDQUFnQmEsTUFBaEIsR0FBeUIsRUFBekI7QUFDSCxHQWhCSTtBQWtCTEMsRUFBQUEsS0FsQkssbUJBa0JJLENBQ1IsQ0FuQkk7QUFxQkw7QUFDQUMsRUFBQUEsV0FBVyxFQUFDLHFCQUFTQyxNQUFULEVBQWdCQyxHQUFoQixFQUFvQjtBQUM1QkMsSUFBQUEsR0FBRyxDQUFDQyxTQUFKLENBQWNGLEdBQWQ7QUFDSCxHQXhCSSxDQTBCTDs7QUExQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBsYl9zaG93SW5wdXQ6IGNjLkxhYmVsLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL+i+k+WFpVxyXG4gICAgICAgIGxiX3ByZVN0ZXA6IGNjLkxhYmVsLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8v6L6T5Ye6XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgbGV0IHdpbiA9IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKSA7XHJcbiAgICAgICAgY2Mudmlldy5zZXREZXNpZ25SZXNvbHV0aW9uU2l6ZSh3aW4ud2lkdGgsIHdpbi5oZWlnaHQsIGNjLlJlc29sdXRpb25Qb2xpY3kuRVhBQ1RfRklUKTtcclxuICAgICAgICB3aW5kb3cuc3RkID0gdGhpcztcclxuICAgICAgICB0aGlzLmxiX3Nob3dJbnB1dC5zdHJpbmcgPSAnMCc7XHJcbiAgICAgICAgdGhpcy5sYl9wcmVTdGVwLnN0cmluZyA9ICcnO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5oyJ6ZKu54K55Ye75Zue6LCDXHJcbiAgICBidG5DYWxsQmFjazpmdW5jdGlvbihzZW5kZXIsc3RyKXtcclxuICAgICAgICBjYWwuaGFuZGxlS2V5KHN0cilcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=