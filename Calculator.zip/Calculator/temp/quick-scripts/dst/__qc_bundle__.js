
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/FullScreenAdapter');
require('./assets/Script/Globals');
require('./assets/Script/Standard');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Globals.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '78255rNTFlBep9MloizMVp/', 'Globals');
// Script/Globals.js

"use strict";

window.m_cal = {
  //操作数栈
  operandStack: [],
  //运算符栈
  operatorStack: [],
  //上一次输入是否是二元运算符，如果是并且再次输入二元运算符，那么忽略此次输入
  isPreInputBinaryOperator: false,
  //上次按键是否是一元操作
  isPreInputUnaryOperator: false,
  //等号不可以连按
  isPreInputEquals: false,
  //如果为true，那么接下来输入的数字需要覆盖在showInput上，而不是追加
  //上一次计算的结果(=)
  preResult: 0,
  //当前使用的进制(只在程序员中有效),默认10进制(DEC)
  currentScale: 10,
  isOverride: false
}; //todo

window.cal = Object.freeze({
  //计算器按键编码
  keyCodes: {
    0: '0',
    1: '1',
    2: '2',
    3: '3',
    4: '4',
    5: '5',
    6: '6',
    7: '7',
    8: '8',
    9: '9',
    10: '.',
    11: '±',
    12: '=',
    13: '+',
    14: '-',
    15: '*',
    16: '/',
    17: '%',
    18: '√',
    19: 'x2',
    20: '1/x',
    21: '(',
    22: ')',
    23: 'yroot',
    24: 'n!',
    25: 'Exp',
    26: '^',
    27: 'sin',
    28: 'cos',
    29: 'tan',
    30: 'powten',
    31: 'log',
    32: 'sinh',
    33: 'cosh',
    34: 'tanh',
    35: 'π',
    36: '↑',
    37: 'CE',
    38: 'C',
    39: 'Back',
    //以下是程序员型特有的按键
    40: 'A',
    41: 'B',
    42: 'C',
    43: 'D',
    44: 'E',
    45: 'F',
    46: '&',
    47: '|',
    48: '~'
  },
  //映射用于显示的操作符，比如计算时用*，而显示时x更好
  operatorFacade: {
    13: '+',
    14: '-',
    15: '×',
    16: '÷',
    17: '%',
    23: 'yroot',
    26: '^',
    46: '&',
    47: '|'
  },
  //当前计算器的类型1 --> 标准型, 2-->科学型， 3-->程序员型，默认标准型
  type: 1,
  //计算器类型前缀，用于从页面获取元素
  typePrefix: {
    1: "std-",
    2: "sci-",
    3: "pro-"
  },
  //记录每个类型的计算器的事件监听是否已经绑定,key:typpe数值，value:默认标准型是true(已加载)
  hasInited: {
    1: true,
    2: false,
    3: false
  },
  cache: {
    //输入内容显示元素
    showInput: null,
    //上一步计算结果显示区域
    preStep: null,
    //显示四种进制数值的span，只在程序员型有效
    scaleSpans: null
  },

  /**
   * 获取cache.showInput的内容
   * @return String
   */
  getShowInput: function getShowInput() {
    return std.lb_showInput.string;
  },

  /**
   * 设置showInput的值
   * @param value
   */
  setShowInput: function setShowInput(value) {
    std.lb_showInput.string = value;
  },

  /**
   * 获取cache.preStep的内容
   * @return String
   */
  getPreStep: function getPreStep() {
    return std.lb_preStep.string;
  },
  setPreStep: function setPreStep(value) {
    std.lb_preStep.string = value;
  },
  //int校验
  intPattern: /^-?\d+$/,
  //小数校验
  floatPattern: /^-?\d+\.\d+$/,
  //科学计数法校验
  scientificPattern: /^\d+\.\d+e(\+|-)\d+$/,
  //校验16进制数字
  hexPattern: /^[0-9A-F]+$/,
  //辅助判断运算符的优先级
  operatorPriority: {
    ")": 0,
    "|": 1,
    "&": 2,
    "+": 3,
    "-": 3,
    "*": 4,
    "%": 4,
    "/": 4,
    "^": 5,
    "yroot": 5,
    "(": 6
  },

  /**
   * 相应按键按下事件
   * @param value 按键的value值(即其keyCode)
   */
  handleKey: function handleKey(value) {
    var keyCode = parseInt(value); //如果是一个数字或者小数点，直接显示出来

    if (keyCode < 11 || keyCode > 39 && keyCode < 46) {
      cal.showInput(cal.keyCodes[keyCode]);

      if (cal.type === 3) {
        //如果是程序员型，那么需要同步显示4中进制的值
        cal.showScales(cal.getShowInput());
      }
    } else {
      switch (keyCode) {
        //正负号
        case 11:
          cal.unaryOperate(function (oldValue) {
            oldValue += "";

            if (oldValue === "0") {
              return [oldValue];
            }

            if (oldValue.charAt(0) === '-') {
              return [oldValue.substring(1)];
            } else {
              return ["-" + oldValue];
            }
          });
          break;
        //开根下

        case 18:
          cal.unaryOperate(function (si) {
            return [Math.sqrt(si), "sqrt"];
          });
          break;
        //平方

        case 19:
          cal.unaryOperate(function (si) {
            return [Math.pow(si, 2), "sqr"];
          });
          break;
        //取倒数

        case 20:
          cal.unaryOperate(function (si) {
            return [si === 0 ? "0不能作被除数" : 1 / si, "1/"];
          });
          break;
        //阶乘

        case 24:
          cal.unaryOperate(function (si) {
            if (si < 0) {
              si = 0 - si;
            }

            if (cal.isFloat(si + "")) {
              si = Math.floor(si);
            }

            return [cal.fact(si), "fact"];
          });
          break;
        //Exp 转为科学计数法表示

        case 25:
          cal.unaryOperate(function (si) {
            return [si.toExponential(7)];
          });
          break;
        //sin

        case 27:
          cal.unaryOperate(function (si) {
            return [Math.sin(si), "sin"];
          });
          break;
        //cos

        case 28:
          cal.unaryOperate(function (si) {
            return [Math.cos(si), "cos"];
          });
          break;
        //tan

        case 29:
          cal.unaryOperate(function (si) {
            return [Math.tan(si), "tan"];
          });
          break;
        //10的x次方

        case 30:
          cal.unaryOperate(function (si) {
            return [Math.pow(10, si), "powten"];
          });
          break;
        //log

        case 31:
          cal.unaryOperate(function (si) {
            //js的Math.log是e的对数，Windows计算器是10的对数，此处参考Windows
            return [Math.log10(si), "log"];
          });
          break;
        //sinh(双曲正弦函数)

        case 32:
          cal.unaryOperate(function (si) {
            return [Math.sinh(si), "sinh"];
          });
          break;
        //cosh(双曲余弦函数)

        case 33:
          cal.unaryOperate(function (si) {
            return [Math.cosh(si), "cosh"];
          });
          break;
        //tanh(双曲余切函数)

        case 34:
          cal.unaryOperate(function (si) {
            return [Math.tanh(si), "tanh"];
          });
          break;
        //π

        case 35:
          cal.unaryOperate(function (si) {
            return [Math.PI];
          });
          break;
        //按位取反(~)

        case 48:
          cal.unaryOperate(function (si) {
            var result = eval("~" + si); //显示四种进制的数值

            cal.showScales(result);
            return [result];
          });
          break;
        //二元运算符开始
        //加、减、乘、除、取余，运算比较简单，直接利用eval即可求值

        case 13:
        case 14:
        case 15:
        case 16:
        case 17: //x的y次方

        case 26: //开任意次方根

        case 23: //And Or

        case 46:
        case 47:
          if (m_cal.isPreInputBinaryOperator) {
            break;
          }

          m_cal.isPreInputBinaryOperator = true;
          m_cal.isOverride = true;
          cal.binaryOperate(cal.keyCodes[keyCode], cal.operatorFacade[keyCode]);
          break;

        case 12:
          cal.calculate();
          break;
        //ce

        case 37:
          cal.ce();
          break;
        //c

        case 38:
          cal.clear();
          break;
        //back

        case 39:
          cal.back();
          break;
        // (

        case 21:
          cal.setPreStep(cal.getPreStep() + " (");
          m_cal.operatorStack.push("(");
          break;
        // )

        case 22:
          cal.rightTag();
          break;
        //向上箭头，把上次计算结果显示出来

        case 36:
          cal.setShowInput(m_cal.preResult);
          break;
      }
    }
  },

  /**
   * 执行一元运算 比如取倒数、平方
   * @param operation 具体运算回调函数
   * 会向operation传递一个参数si，为用户当前的输入，同时operation函数应该返回一个数组，数组的第一个
   * 元素是计算的结果，第二个元素示例sqrt，第二个参数可选
   */
  unaryOperate: function unaryOperate(operation) {
    var si = cal.getShowInput(),
        result;

    if (cal.isInteger(si)) {
      result = operation(parseInt(si));
    } else if (cal.isFloat(si) || cal.isScientific(si)) {
      result = operation(parseFloat(si));
    }

    if (result != null) {
      cal.setShowInput(cal.checkLength(result[0]));

      if (result.length > 1) {
        //显示prestep有两种情况:
        //第一种就是这是第一次(指连续调用的第一次)调用一元函数，此时直接接在末尾即可
        if (!m_cal.isPreInputUnaryOperator) {
          cal.setPreStep(cal.getPreStep() + " " + result[1] + "(" + si + ")");
          m_cal.isPreInputUnaryOperator = true;
        } else {
          //第二种就是这不是第一次，那么应该截取最后一个空格之后的内容进行替换
          //比如1 + 3 + sqrt(100)，那么应该从最后一个空格后替换为此次操作的内容
          var pi = cal.getPreStep();
          pi = pi.substring(0, pi.lastIndexOf(" "));
          pi += " " + result[1] + "(" + si + ")";
          cal.setPreStep(pi);
        }
      } //一元运算结束后应该覆盖


      m_cal.isOverride = true;
    }

    m_cal.isPreInputBinaryOperator = false;
  },

  /**
   * 二元操作(+ - * / %)
   * @param operator 操作符
   * @param facade 运算符门面，用于显示在preStep中
   */
  binaryOperate: function binaryOperate(operator, facade) {
    //如果是程序员型，那么需要重置scalesSpan
    if (cal.type === 3) {
      cal.resetScales();
    }

    var si = cal.getShowInput(),
        pi = cal.getPreStep();

    if (cal.isNumber(si)) {
      //压操作数栈
      m_cal.operandStack.push(si); //设置preStep有三种情况:第一种上一步不是一元操作，那么需要设置si，第二种是一元操作，那么由于一元操作会把
      //函数表达式(比如sqrt(100))设置到preStep，所以不需要再次设置si
      //第三种就是如果最后一位是右括号，那么也不需要设置si

      cal.setPreStep(cal.getPreStep() + (m_cal.isPreInputUnaryOperator || pi.charAt(pi.length - 1) === ")" ? " " + facade : " " + si + " " + facade));
      var preOp = m_cal.operatorStack.pop();

      if (preOp != null) {
        var op = cal.operatorPriority[operator],
            pp = cal.operatorPriority[preOp]; //如果当前运算符优先级更高，那么只需压栈不需要计算

        if (op > pp) {
          m_cal.operatorStack.push(preOp);
        } //两者的优先级相等并且高于3(加减)，那么只需要计算一步
        else if (op > 3 && op === pp) {
            m_cal.operatorStack.push(preOp);
            cal.travelStack(1);
          } else {
            m_cal.operatorStack.push(preOp);
            cal.setShowInput(cal.checkLength(cal.travelStack(null, op)));
          }
      }

      m_cal.operatorStack.push(operator);
    }

    m_cal.isPreInputUnaryOperator = false;
    m_cal.isPreInputEquals = false;
  },

  /**
   * 按下=时计算最终结果
   */
  calculate: function calculate() {
    if (!m_cal.isPreInputEquals) {
      var si = cal.getShowInput(),
          result;

      if (cal.isNumber(si)) {
        m_cal.operandStack.push(si);
        result = cal.checkLength(cal.travelStack());
        cal.setShowInput(result);
        m_cal.preResult = result;
        cal.setPreStep(""); //程序员型需要把计算结果的四种进制值显示出来

        if (cal.type === 3) {
          cal.showScales(result);
        }

        m_cal.isOverride = true;
      }

      cal._reset();

      m_cal.isPreInputEquals = true;
    }
  },

  /**
   * 访问运算栈，返回计算结果
   * @param level 计算的层数，如果不指定，那么遍历整个栈
   * @param minPri(最小/截止优先级) 此参数针对下面的情况:
   * 2 + 2 X 3 X 2 ^ 2 X 2，由于最后一个运算符是X，优先级比^低，所以触发了对操作栈的遍历，但是不能全部遍历，应该遍历到第一个X停止
   * 如果不停止得到的将是错误的26 X 2 = 52，正确结果是2 + 24 X 2 = 50
   * @return Number
   * @private
   */
  travelStack: function travelStack(level, minPri) {
    var op,
        f,
        s,
        //result取操作数栈栈顶，因为防止在下列情况9 X (6 + 时出现undefined
    result = m_cal.operandStack[m_cal.operandStack.length - 1],
        l = level || m_cal.operatorStack.length,
        p = minPri || 0;

    for (var i = 0; i < l; ++i) {
      op = m_cal.operatorStack.pop(); //遇到minPri或左括号立即停止，左括号也需要再次压入，因为只有一个右括号才能抵消一个左括号

      if (cal.operatorPriority[op] < p || op === "(") {
        m_cal.operatorStack.push(op);
        break;
      }

      s = m_cal.operandStack.pop();
      f = m_cal.operandStack.pop();
      result = cal._stackHelper(f, s, op);
      m_cal.operandStack.push(result);
    }

    return result;
  },

  /**
   * 输入了一个右括号
   */
  rightTag: function rightTag() {
    var si = cal.getShowInput();

    if (cal.isNumber(si)) {
      cal.setPreStep(cal.getPreStep() + (" " + si + " )"));
      m_cal.operandStack.push(si); //遍历计算操作栈，直至遇到左括号

      var op = m_cal.operatorStack.pop(),
          f,
          s,
          result;

      while (op !== "(" && op != null) {
        s = m_cal.operandStack.pop();
        f = m_cal.operandStack.pop();
        result = cal._stackHelper(f, s, op);
        m_cal.operandStack.push(result);
        op = m_cal.operatorStack.pop();
      } //此处应该直接把小括号的计算内容弹出，因为此结果显示在了showInput中，而再次执行二元操作时会先有一个压栈的操作，
      // 并且执行=时也是根据showInput内容计算的


      cal.setShowInput(cal.checkLength(m_cal.operandStack.pop()));
    }
  },

  /**
   * 辅助进行一次栈运算
   * @param f 第一个操作数
   * @param s 第二个操作数
   * @param op 运算符
   * @return 返回运算结果
   * @private
   */
  _stackHelper: function _stackHelper(f, s, op) {
    var result;

    if (op === "^") {
      result = Math.pow(f, s);
    } else if (op === "yroot") {
      result = Math.pow(f, 1 / s);
    } //+ - X / %5中操作
    else {
        //如果是程序员型，那么需要考虑进制的问题
        if (cal.type === 3) {
          var scale = m_cal.currentScale,
              fi,
              si;

          if (scale === 10) {
            result = eval(f + op + s);
          } else if (scale === 16) {
            fi = parseInt(f, 16);
            si = parseInt(s, 16);
            result = eval(fi + op + si).toString(16);
          } else if (scale === 8) {
            fi = parseInt(f, 8);
            si = parseInt(s, 8);
            result = eval(fi + op + si).toString(8);
          } else {
            fi = parseInt(f, 2);
            si = parseInt(s, 2);
            result = eval(fi + op + si).toString(2);
          }
        } else {
          result = eval(f + op + s);
        }
      }

    return result;
  },

  /**
   * 确保结果长度不大于13,如果超出，以科学计数法形式显示(小数点后7位)
   * @param value 需要检查的结果
   */
  checkLength: function checkLength(value) {
    var valueStr = value + "";

    if (cal.isFloat(valueStr)) {
      valueStr = valueStr.replace(/0+$/, "");
    }

    return valueStr.length > 12 ? value.toExponential(7) : valueStr;
  },
  //CE
  ce: function ce() {
    cal.setShowInput("0");

    if (cal.type === 3) {
      cal.resetScales();
    }
  },
  //C
  clear: function clear() {
    cal.setShowInput("0");
    cal.setPreStep("");

    cal._reset();

    if (cal.type === 3) {
      cal.resetScales();
    }
  },

  /**
   * 清空四个进制的值
   * @private
   */
  resetScales: function resetScales() {
    for (var i = 0; i < 4; i++) {
      cal.cache.scaleSpans[i].string = "0";
    }
  },
  back: function back() {
    var oldValue = cal.getShowInput();
    cal.setShowInput(oldValue.length < 2 ? "0" : oldValue.substring(0, oldValue.length - 1));
  },

  /**
   * 当计算器类型是程序员时，需要同步显示四种进制的值
   * @param num 需要显示的数字
   */
  showScales: function showScales(num) {
    var result = cal.calculateScales(num),
        spans = cal.cache.scaleSpans;

    for (var i = 0; i < 4; ++i) {
      spans[i].string = result[i];
    }
  },

  /**
   * 根据当前进制分别计算出四种进制的值
   * @param num 需要计算的值
   * @return Array 共4个元素，依次为16、10、8、2进制的值
   */
  calculateScales: function calculateScales(num) {
    var scale = m_cal.currentScale,
        result = [],
        i;

    if (scale === 10) {
      i = parseInt(num);
      result[0] = i.toString(16);
      result[1] = i;
      result[2] = i.toString(8);
      result[3] = i.toString(2);
    } else if (scale === 16) {
      //先转成10进制，然后再转成其它进制
      i = parseInt(num, 16);
      result[0] = num;
      result[1] = i;
      result[2] = i.toString(8);
      result[3] = i.toString(2);
    } else if (scale === 8) {
      i = parseInt(num, 8);
      result[0] = i.toString(16);
      result[1] = i;
      result[2] = num;
      result[3] = i.toString(2);
    } else {
      i = parseInt(num, 2);
      result[0] = i.toString(16);
      result[1] = i;
      result[2] = i.toString(8);
      result[3] = num;
    }

    return result;
  },

  /**
   * 校验字符串是否是数字
   * @param str
   * @return 是返回true
   */
  isNumber: function isNumber(str) {
    return cal.isInteger(str) || cal.isFloat(str) || cal.isScientific(str) || cal.isHex(str);
  },

  /**
   * 校验是否是整数
   * @param str
   */
  isInteger: function isInteger(str) {
    return str.match(cal.intPattern);
  },

  /**
   * 校验是否是小数
   * @param str
   */
  isFloat: function isFloat(str) {
    return str.match(cal.floatPattern);
  },

  /**
   * 是否是科学计数法
   * @param str
   */
  isScientific: function isScientific(str) {
    return str.match(cal.scientificPattern);
  },

  /**
   * 是否是16进制数字
   * @param str
   */
  isHex: function isHex(str) {
    return str.match(cal.hexPattern);
  },

  /**
   * 显示输入的内容
   * 用于相应数字/小数点按键
   * @param value 按键的内容，不是keyCode
   */
  showInput: function showInput(value) {
    var oldValue = cal.getShowInput();
    var newValue = oldValue;

    if (m_cal.isOverride) {
      //既然是覆盖，那么如果直接输入.那么肯定是0.x
      if (value === ".") {
        newValue = "0.";
      } else {
        newValue = value;
      }
    } else if (oldValue.length < 13) {
      if (oldValue === "0") {
        if (value === ".") {
          newValue = "0.";
        } else {
          newValue = value;
        }
      } else {
        newValue += value;
      }
    }

    cal.setShowInput(newValue);
    m_cal.isOverride = false;
    m_cal.isPreInputBinaryOperator = false;
    m_cal.isPreInputUnaryOperator = false;
    m_cal.isPreInputEquals = false;
  },

  /**
   * 切换计算器类型
   * @param type int 要切换到的类型
   */
  switchType: function switchType(type) {
    //关闭选择栏
    var oldPrefix = cal.typePrefix[cal.type];
    document.getElementById(oldPrefix + "type-bar").style.display = "none"; //切换面板

    document.getElementById(oldPrefix + "main").style.display = "none";
    document.getElementById(cal.typePrefix[type] + "main").style.display = "block";
    cal.type = type;

    if (!cal.hasInited[type]) {
      cal.initListeners();
      cal.hasInited[type] = true;
    }

    cal.initCache();

    cal._reset();
  },

  /**
   * 重置各个标志变量以及操作栈
   * @private
   */
  _reset: function _reset() {
    m_cal.operandStack = [];
    m_cal.operatorStack = [];
    m_cal.isPreInputBinaryOperator = false;
    m_cal.isPreInputUnaryOperator = false;
    m_cal.isPreInputEquals = false;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHbG9iYWxzLmpzIl0sIm5hbWVzIjpbIndpbmRvdyIsIm1fY2FsIiwib3BlcmFuZFN0YWNrIiwib3BlcmF0b3JTdGFjayIsImlzUHJlSW5wdXRCaW5hcnlPcGVyYXRvciIsImlzUHJlSW5wdXRVbmFyeU9wZXJhdG9yIiwiaXNQcmVJbnB1dEVxdWFscyIsInByZVJlc3VsdCIsImN1cnJlbnRTY2FsZSIsImlzT3ZlcnJpZGUiLCJjYWwiLCJPYmplY3QiLCJmcmVlemUiLCJrZXlDb2RlcyIsIm9wZXJhdG9yRmFjYWRlIiwidHlwZSIsInR5cGVQcmVmaXgiLCJoYXNJbml0ZWQiLCJjYWNoZSIsInNob3dJbnB1dCIsInByZVN0ZXAiLCJzY2FsZVNwYW5zIiwiZ2V0U2hvd0lucHV0Iiwic3RkIiwibGJfc2hvd0lucHV0Iiwic3RyaW5nIiwic2V0U2hvd0lucHV0IiwidmFsdWUiLCJnZXRQcmVTdGVwIiwibGJfcHJlU3RlcCIsInNldFByZVN0ZXAiLCJpbnRQYXR0ZXJuIiwiZmxvYXRQYXR0ZXJuIiwic2NpZW50aWZpY1BhdHRlcm4iLCJoZXhQYXR0ZXJuIiwib3BlcmF0b3JQcmlvcml0eSIsImhhbmRsZUtleSIsImtleUNvZGUiLCJwYXJzZUludCIsInNob3dTY2FsZXMiLCJ1bmFyeU9wZXJhdGUiLCJvbGRWYWx1ZSIsImNoYXJBdCIsInN1YnN0cmluZyIsInNpIiwiTWF0aCIsInNxcnQiLCJwb3ciLCJpc0Zsb2F0IiwiZmxvb3IiLCJmYWN0IiwidG9FeHBvbmVudGlhbCIsInNpbiIsImNvcyIsInRhbiIsImxvZzEwIiwic2luaCIsImNvc2giLCJ0YW5oIiwiUEkiLCJyZXN1bHQiLCJldmFsIiwiYmluYXJ5T3BlcmF0ZSIsImNhbGN1bGF0ZSIsImNlIiwiY2xlYXIiLCJiYWNrIiwicHVzaCIsInJpZ2h0VGFnIiwib3BlcmF0aW9uIiwiaXNJbnRlZ2VyIiwiaXNTY2llbnRpZmljIiwicGFyc2VGbG9hdCIsImNoZWNrTGVuZ3RoIiwibGVuZ3RoIiwicGkiLCJsYXN0SW5kZXhPZiIsIm9wZXJhdG9yIiwiZmFjYWRlIiwicmVzZXRTY2FsZXMiLCJpc051bWJlciIsInByZU9wIiwicG9wIiwib3AiLCJwcCIsInRyYXZlbFN0YWNrIiwiX3Jlc2V0IiwibGV2ZWwiLCJtaW5QcmkiLCJmIiwicyIsImwiLCJwIiwiaSIsIl9zdGFja0hlbHBlciIsInNjYWxlIiwiZmkiLCJ0b1N0cmluZyIsInZhbHVlU3RyIiwicmVwbGFjZSIsIm51bSIsImNhbGN1bGF0ZVNjYWxlcyIsInNwYW5zIiwic3RyIiwiaXNIZXgiLCJtYXRjaCIsIm5ld1ZhbHVlIiwic3dpdGNoVHlwZSIsIm9sZFByZWZpeCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJzdHlsZSIsImRpc3BsYXkiLCJpbml0TGlzdGVuZXJzIiwiaW5pdENhY2hlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUNBQSxNQUFNLENBQUNDLEtBQVAsR0FBZTtBQUNYO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSxFQUZIO0FBR1g7QUFDQUMsRUFBQUEsYUFBYSxFQUFFLEVBSko7QUFLWDtBQUNBQyxFQUFBQSx3QkFBd0IsRUFBRSxLQU5mO0FBT1g7QUFDQUMsRUFBQUEsdUJBQXVCLEVBQUUsS0FSZDtBQVNYO0FBQ0FDLEVBQUFBLGdCQUFnQixFQUFFLEtBVlA7QUFXWDtBQUNBO0FBQ0FDLEVBQUFBLFNBQVMsRUFBRSxDQWJBO0FBY1g7QUFDQUMsRUFBQUEsWUFBWSxFQUFFLEVBZkg7QUFnQlhDLEVBQUFBLFVBQVUsRUFBRTtBQWhCRCxDQUFmLEVBbUJBOztBQUNBVCxNQUFNLENBQUNVLEdBQVAsR0FBYUMsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFDdkI7QUFDQUMsRUFBQUEsUUFBUSxFQUFFO0FBQ04sT0FBRyxHQURHO0FBRU4sT0FBRyxHQUZHO0FBR04sT0FBRyxHQUhHO0FBSU4sT0FBRyxHQUpHO0FBS04sT0FBRyxHQUxHO0FBTU4sT0FBRyxHQU5HO0FBT04sT0FBRyxHQVBHO0FBUU4sT0FBRyxHQVJHO0FBU04sT0FBRyxHQVRHO0FBVU4sT0FBRyxHQVZHO0FBV04sUUFBSSxHQVhFO0FBWU4sUUFBSSxHQVpFO0FBYU4sUUFBSSxHQWJFO0FBY04sUUFBSSxHQWRFO0FBZU4sUUFBSSxHQWZFO0FBZ0JOLFFBQUksR0FoQkU7QUFpQk4sUUFBSSxHQWpCRTtBQWtCTixRQUFJLEdBbEJFO0FBbUJOLFFBQUksR0FuQkU7QUFvQk4sUUFBSSxJQXBCRTtBQXFCTixRQUFJLEtBckJFO0FBc0JOLFFBQUksR0F0QkU7QUF1Qk4sUUFBSSxHQXZCRTtBQXdCTixRQUFJLE9BeEJFO0FBeUJOLFFBQUksSUF6QkU7QUEwQk4sUUFBSSxLQTFCRTtBQTJCTixRQUFJLEdBM0JFO0FBNEJOLFFBQUksS0E1QkU7QUE2Qk4sUUFBSSxLQTdCRTtBQThCTixRQUFJLEtBOUJFO0FBK0JOLFFBQUksUUEvQkU7QUFnQ04sUUFBSSxLQWhDRTtBQWlDTixRQUFJLE1BakNFO0FBa0NOLFFBQUksTUFsQ0U7QUFtQ04sUUFBSSxNQW5DRTtBQW9DTixRQUFJLEdBcENFO0FBcUNOLFFBQUksR0FyQ0U7QUFzQ04sUUFBSSxJQXRDRTtBQXVDTixRQUFJLEdBdkNFO0FBd0NOLFFBQUksTUF4Q0U7QUF5Q047QUFDQSxRQUFJLEdBMUNFO0FBMkNOLFFBQUksR0EzQ0U7QUE0Q04sUUFBSSxHQTVDRTtBQTZDTixRQUFJLEdBN0NFO0FBOENOLFFBQUksR0E5Q0U7QUErQ04sUUFBSSxHQS9DRTtBQWdETixRQUFJLEdBaERFO0FBaUROLFFBQUksR0FqREU7QUFrRE4sUUFBSTtBQWxERSxHQUZhO0FBc0R2QjtBQUNBQyxFQUFBQSxjQUFjLEVBQUU7QUFDWixRQUFJLEdBRFE7QUFFWixRQUFJLEdBRlE7QUFHWixRQUFJLEdBSFE7QUFJWixRQUFJLEdBSlE7QUFLWixRQUFJLEdBTFE7QUFNWixRQUFJLE9BTlE7QUFPWixRQUFJLEdBUFE7QUFRWixRQUFJLEdBUlE7QUFTWixRQUFJO0FBVFEsR0F2RE87QUFrRXZCO0FBQ0FDLEVBQUFBLElBQUksRUFBRSxDQW5FaUI7QUFvRXZCO0FBQ0FDLEVBQUFBLFVBQVUsRUFBRTtBQUNSLE9BQUcsTUFESztBQUVSLE9BQUcsTUFGSztBQUdSLE9BQUc7QUFISyxHQXJFVztBQTBFdkI7QUFDQUMsRUFBQUEsU0FBUyxFQUFFO0FBQ1AsT0FBRyxJQURJO0FBRVAsT0FBRyxLQUZJO0FBR1AsT0FBRztBQUhJLEdBM0VZO0FBZ0Z2QkMsRUFBQUEsS0FBSyxFQUFFO0FBQ0g7QUFDQUMsSUFBQUEsU0FBUyxFQUFFLElBRlI7QUFHSDtBQUNBQyxJQUFBQSxPQUFPLEVBQUUsSUFKTjtBQUtIO0FBQ0FDLElBQUFBLFVBQVUsRUFBRTtBQU5ULEdBaEZnQjs7QUF3RnZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0lDLEVBQUFBLFlBQVksRUFBRSx3QkFBWTtBQUN0QixXQUFPQyxHQUFHLENBQUNDLFlBQUosQ0FBaUJDLE1BQXhCO0FBQ0gsR0E5RnNCOztBQStGdkI7QUFDSjtBQUNBO0FBQ0E7QUFDSUMsRUFBQUEsWUFBWSxFQUFFLHNCQUFVQyxLQUFWLEVBQWlCO0FBQzNCSixJQUFBQSxHQUFHLENBQUNDLFlBQUosQ0FBaUJDLE1BQWpCLEdBQTBCRSxLQUExQjtBQUNILEdBckdzQjs7QUFzR3ZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0lDLEVBQUFBLFVBQVUsRUFBRSxzQkFBWTtBQUNwQixXQUFPTCxHQUFHLENBQUNNLFVBQUosQ0FBZUosTUFBdEI7QUFDSCxHQTVHc0I7QUE2R3ZCSyxFQUFBQSxVQUFVLEVBQUUsb0JBQVVILEtBQVYsRUFBaUI7QUFDekJKLElBQUFBLEdBQUcsQ0FBQ00sVUFBSixDQUFlSixNQUFmLEdBQXdCRSxLQUF4QjtBQUNILEdBL0dzQjtBQWlIdkI7QUFDQUksRUFBQUEsVUFBVSxFQUFFLFNBbEhXO0FBbUh2QjtBQUNBQyxFQUFBQSxZQUFZLEVBQUUsY0FwSFM7QUFxSHZCO0FBQ0FDLEVBQUFBLGlCQUFpQixFQUFFLHNCQXRISTtBQXVIdkI7QUFDQUMsRUFBQUEsVUFBVSxFQUFFLGFBeEhXO0FBeUh2QjtBQUNBQyxFQUFBQSxnQkFBZ0IsRUFBRTtBQUNkLFNBQUssQ0FEUztBQUVkLFNBQUssQ0FGUztBQUdkLFNBQUssQ0FIUztBQUlkLFNBQUssQ0FKUztBQUtkLFNBQUssQ0FMUztBQU1kLFNBQUssQ0FOUztBQU9kLFNBQUssQ0FQUztBQVFkLFNBQUssQ0FSUztBQVNkLFNBQUssQ0FUUztBQVVkLGFBQVMsQ0FWSztBQVdkLFNBQUs7QUFYUyxHQTFISzs7QUF3SXZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0lDLEVBQUFBLFNBQVMsRUFBRSxtQkFBVVQsS0FBVixFQUFpQjtBQUN4QixRQUFJVSxPQUFPLEdBQUdDLFFBQVEsQ0FBQ1gsS0FBRCxDQUF0QixDQUR3QixDQUV4Qjs7QUFDQSxRQUFJVSxPQUFPLEdBQUcsRUFBVixJQUFpQkEsT0FBTyxHQUFHLEVBQVYsSUFBZ0JBLE9BQU8sR0FBRyxFQUEvQyxFQUFvRDtBQUNoRDNCLE1BQUFBLEdBQUcsQ0FBQ1MsU0FBSixDQUFjVCxHQUFHLENBQUNHLFFBQUosQ0FBYXdCLE9BQWIsQ0FBZDs7QUFDQSxVQUFJM0IsR0FBRyxDQUFDSyxJQUFKLEtBQWEsQ0FBakIsRUFBb0I7QUFDaEI7QUFDQUwsUUFBQUEsR0FBRyxDQUFDNkIsVUFBSixDQUFlN0IsR0FBRyxDQUFDWSxZQUFKLEVBQWY7QUFDSDtBQUNKLEtBTkQsTUFNTztBQUNILGNBQVFlLE9BQVI7QUFDSTtBQUNBLGFBQUssRUFBTDtBQUNJM0IsVUFBQUEsR0FBRyxDQUFDOEIsWUFBSixDQUFpQixVQUFVQyxRQUFWLEVBQW9CO0FBQ2pDQSxZQUFBQSxRQUFRLElBQUksRUFBWjs7QUFDQSxnQkFBSUEsUUFBUSxLQUFLLEdBQWpCLEVBQXNCO0FBQ2xCLHFCQUFPLENBQUNBLFFBQUQsQ0FBUDtBQUNIOztBQUNELGdCQUFJQSxRQUFRLENBQUNDLE1BQVQsQ0FBZ0IsQ0FBaEIsTUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIscUJBQU8sQ0FBQ0QsUUFBUSxDQUFDRSxTQUFULENBQW1CLENBQW5CLENBQUQsQ0FBUDtBQUNILGFBRkQsTUFFTztBQUNILHFCQUFPLENBQUMsTUFBTUYsUUFBUCxDQUFQO0FBQ0g7QUFDSixXQVZEO0FBV0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSS9CLFVBQUFBLEdBQUcsQ0FBQzhCLFlBQUosQ0FBaUIsVUFBVUksRUFBVixFQUFjO0FBQzNCLG1CQUFPLENBQUNDLElBQUksQ0FBQ0MsSUFBTCxDQUFVRixFQUFWLENBQUQsRUFBZ0IsTUFBaEIsQ0FBUDtBQUNILFdBRkQ7QUFHQTtBQUNKOztBQUNBLGFBQUssRUFBTDtBQUNJbEMsVUFBQUEsR0FBRyxDQUFDOEIsWUFBSixDQUFpQixVQUFVSSxFQUFWLEVBQWM7QUFDM0IsbUJBQU8sQ0FBQ0MsSUFBSSxDQUFDRSxHQUFMLENBQVNILEVBQVQsRUFBYSxDQUFiLENBQUQsRUFBa0IsS0FBbEIsQ0FBUDtBQUNILFdBRkQ7QUFHQTtBQUNKOztBQUNBLGFBQUssRUFBTDtBQUNJbEMsVUFBQUEsR0FBRyxDQUFDOEIsWUFBSixDQUFpQixVQUFVSSxFQUFWLEVBQWM7QUFDM0IsbUJBQU8sQ0FBQ0EsRUFBRSxLQUFLLENBQVAsR0FBVyxTQUFYLEdBQXVCLElBQUlBLEVBQTVCLEVBQWdDLElBQWhDLENBQVA7QUFDSCxXQUZEO0FBR0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSWxDLFVBQUFBLEdBQUcsQ0FBQzhCLFlBQUosQ0FBaUIsVUFBVUksRUFBVixFQUFjO0FBQzNCLGdCQUFJQSxFQUFFLEdBQUcsQ0FBVCxFQUFZO0FBQ1JBLGNBQUFBLEVBQUUsR0FBSSxJQUFJQSxFQUFWO0FBQ0g7O0FBQ0QsZ0JBQUlsQyxHQUFHLENBQUNzQyxPQUFKLENBQVlKLEVBQUUsR0FBRyxFQUFqQixDQUFKLEVBQTBCO0FBQ3RCQSxjQUFBQSxFQUFFLEdBQUdDLElBQUksQ0FBQ0ksS0FBTCxDQUFXTCxFQUFYLENBQUw7QUFDSDs7QUFDRCxtQkFBTyxDQUFDbEMsR0FBRyxDQUFDd0MsSUFBSixDQUFTTixFQUFULENBQUQsRUFBZSxNQUFmLENBQVA7QUFDSCxXQVJEO0FBU0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSWxDLFVBQUFBLEdBQUcsQ0FBQzhCLFlBQUosQ0FBaUIsVUFBVUksRUFBVixFQUFjO0FBQzNCLG1CQUFPLENBQUNBLEVBQUUsQ0FBQ08sYUFBSCxDQUFpQixDQUFqQixDQUFELENBQVA7QUFDSCxXQUZEO0FBR0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSXpDLFVBQUFBLEdBQUcsQ0FBQzhCLFlBQUosQ0FBaUIsVUFBVUksRUFBVixFQUFjO0FBQzNCLG1CQUFPLENBQUNDLElBQUksQ0FBQ08sR0FBTCxDQUFTUixFQUFULENBQUQsRUFBZSxLQUFmLENBQVA7QUFDSCxXQUZEO0FBR0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSWxDLFVBQUFBLEdBQUcsQ0FBQzhCLFlBQUosQ0FBaUIsVUFBVUksRUFBVixFQUFjO0FBQzNCLG1CQUFPLENBQUNDLElBQUksQ0FBQ1EsR0FBTCxDQUFTVCxFQUFULENBQUQsRUFBZSxLQUFmLENBQVA7QUFDSCxXQUZEO0FBR0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSWxDLFVBQUFBLEdBQUcsQ0FBQzhCLFlBQUosQ0FBaUIsVUFBVUksRUFBVixFQUFjO0FBQzNCLG1CQUFPLENBQUNDLElBQUksQ0FBQ1MsR0FBTCxDQUFTVixFQUFULENBQUQsRUFBZSxLQUFmLENBQVA7QUFDSCxXQUZEO0FBR0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSWxDLFVBQUFBLEdBQUcsQ0FBQzhCLFlBQUosQ0FBaUIsVUFBVUksRUFBVixFQUFjO0FBQzNCLG1CQUFPLENBQUNDLElBQUksQ0FBQ0UsR0FBTCxDQUFTLEVBQVQsRUFBYUgsRUFBYixDQUFELEVBQW1CLFFBQW5CLENBQVA7QUFDSCxXQUZEO0FBR0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSWxDLFVBQUFBLEdBQUcsQ0FBQzhCLFlBQUosQ0FBaUIsVUFBVUksRUFBVixFQUFjO0FBQzNCO0FBQ0EsbUJBQU8sQ0FBQ0MsSUFBSSxDQUFDVSxLQUFMLENBQVdYLEVBQVgsQ0FBRCxFQUFpQixLQUFqQixDQUFQO0FBQ0gsV0FIRDtBQUlBO0FBQ0o7O0FBQ0EsYUFBSyxFQUFMO0FBQ0lsQyxVQUFBQSxHQUFHLENBQUM4QixZQUFKLENBQWlCLFVBQVVJLEVBQVYsRUFBYztBQUMzQixtQkFBTyxDQUFDQyxJQUFJLENBQUNXLElBQUwsQ0FBVVosRUFBVixDQUFELEVBQWdCLE1BQWhCLENBQVA7QUFDSCxXQUZEO0FBR0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSWxDLFVBQUFBLEdBQUcsQ0FBQzhCLFlBQUosQ0FBaUIsVUFBVUksRUFBVixFQUFjO0FBQzNCLG1CQUFPLENBQUNDLElBQUksQ0FBQ1ksSUFBTCxDQUFVYixFQUFWLENBQUQsRUFBZ0IsTUFBaEIsQ0FBUDtBQUNILFdBRkQ7QUFHQTtBQUNKOztBQUNBLGFBQUssRUFBTDtBQUNJbEMsVUFBQUEsR0FBRyxDQUFDOEIsWUFBSixDQUFpQixVQUFVSSxFQUFWLEVBQWM7QUFDM0IsbUJBQU8sQ0FBQ0MsSUFBSSxDQUFDYSxJQUFMLENBQVVkLEVBQVYsQ0FBRCxFQUFnQixNQUFoQixDQUFQO0FBQ0gsV0FGRDtBQUdBO0FBQ0o7O0FBQ0EsYUFBSyxFQUFMO0FBQ0lsQyxVQUFBQSxHQUFHLENBQUM4QixZQUFKLENBQWlCLFVBQVVJLEVBQVYsRUFBYztBQUMzQixtQkFBTyxDQUFDQyxJQUFJLENBQUNjLEVBQU4sQ0FBUDtBQUNILFdBRkQ7QUFHQTtBQUNKOztBQUNBLGFBQUssRUFBTDtBQUNJakQsVUFBQUEsR0FBRyxDQUFDOEIsWUFBSixDQUFpQixVQUFVSSxFQUFWLEVBQWM7QUFDM0IsZ0JBQUlnQixNQUFNLEdBQUdDLElBQUksQ0FBQyxNQUFNakIsRUFBUCxDQUFqQixDQUQyQixDQUUzQjs7QUFDQWxDLFlBQUFBLEdBQUcsQ0FBQzZCLFVBQUosQ0FBZXFCLE1BQWY7QUFDQSxtQkFBTyxDQUFDQSxNQUFELENBQVA7QUFDSCxXQUxEO0FBTUE7QUFDSjtBQUNBOztBQUNBLGFBQUssRUFBTDtBQUNBLGFBQUssRUFBTDtBQUNBLGFBQUssRUFBTDtBQUNBLGFBQUssRUFBTDtBQUNBLGFBQUssRUFBTCxDQXpISixDQTBISTs7QUFDQSxhQUFLLEVBQUwsQ0EzSEosQ0E0SEk7O0FBQ0EsYUFBSyxFQUFMLENBN0hKLENBOEhJOztBQUNBLGFBQUssRUFBTDtBQUNBLGFBQUssRUFBTDtBQUNJLGNBQUkzRCxLQUFLLENBQUNHLHdCQUFWLEVBQW9DO0FBQ2hDO0FBQ0g7O0FBQ0RILFVBQUFBLEtBQUssQ0FBQ0csd0JBQU4sR0FBaUMsSUFBakM7QUFDQUgsVUFBQUEsS0FBSyxDQUFDUSxVQUFOLEdBQW1CLElBQW5CO0FBQ0FDLFVBQUFBLEdBQUcsQ0FBQ29ELGFBQUosQ0FBa0JwRCxHQUFHLENBQUNHLFFBQUosQ0FBYXdCLE9BQWIsQ0FBbEIsRUFBeUMzQixHQUFHLENBQUNJLGNBQUosQ0FBbUJ1QixPQUFuQixDQUF6QztBQUNBOztBQUNKLGFBQUssRUFBTDtBQUNJM0IsVUFBQUEsR0FBRyxDQUFDcUQsU0FBSjtBQUNBO0FBQ0o7O0FBQ0EsYUFBSyxFQUFMO0FBQ0lyRCxVQUFBQSxHQUFHLENBQUNzRCxFQUFKO0FBQ0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSXRELFVBQUFBLEdBQUcsQ0FBQ3VELEtBQUo7QUFDQTtBQUNKOztBQUNBLGFBQUssRUFBTDtBQUNJdkQsVUFBQUEsR0FBRyxDQUFDd0QsSUFBSjtBQUNBO0FBQ0o7O0FBQ0EsYUFBSyxFQUFMO0FBQ0l4RCxVQUFBQSxHQUFHLENBQUNvQixVQUFKLENBQWVwQixHQUFHLENBQUNrQixVQUFKLEtBQW1CLElBQWxDO0FBQ0EzQixVQUFBQSxLQUFLLENBQUNFLGFBQU4sQ0FBb0JnRSxJQUFwQixDQUF5QixHQUF6QjtBQUNBO0FBQ0o7O0FBQ0EsYUFBSyxFQUFMO0FBQ0l6RCxVQUFBQSxHQUFHLENBQUMwRCxRQUFKO0FBQ0E7QUFDSjs7QUFDQSxhQUFLLEVBQUw7QUFDSTFELFVBQUFBLEdBQUcsQ0FBQ2dCLFlBQUosQ0FBaUJ6QixLQUFLLENBQUNNLFNBQXZCO0FBQ0E7QUFuS1I7QUFxS0g7QUFDSixHQTVUc0I7O0FBNlR2QjtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSWlDLEVBQUFBLFlBQVksRUFBRSxzQkFBVTZCLFNBQVYsRUFBcUI7QUFDL0IsUUFBSXpCLEVBQUUsR0FBR2xDLEdBQUcsQ0FBQ1ksWUFBSixFQUFUO0FBQUEsUUFDSXNDLE1BREo7O0FBRUEsUUFBSWxELEdBQUcsQ0FBQzRELFNBQUosQ0FBYzFCLEVBQWQsQ0FBSixFQUF1QjtBQUNuQmdCLE1BQUFBLE1BQU0sR0FBR1MsU0FBUyxDQUFDL0IsUUFBUSxDQUFDTSxFQUFELENBQVQsQ0FBbEI7QUFDSCxLQUZELE1BRU8sSUFBSWxDLEdBQUcsQ0FBQ3NDLE9BQUosQ0FBWUosRUFBWixLQUFtQmxDLEdBQUcsQ0FBQzZELFlBQUosQ0FBaUIzQixFQUFqQixDQUF2QixFQUE2QztBQUNoRGdCLE1BQUFBLE1BQU0sR0FBR1MsU0FBUyxDQUFDRyxVQUFVLENBQUM1QixFQUFELENBQVgsQ0FBbEI7QUFDSDs7QUFDRCxRQUFJZ0IsTUFBTSxJQUFJLElBQWQsRUFBb0I7QUFDaEJsRCxNQUFBQSxHQUFHLENBQUNnQixZQUFKLENBQWlCaEIsR0FBRyxDQUFDK0QsV0FBSixDQUFnQmIsTUFBTSxDQUFDLENBQUQsQ0FBdEIsQ0FBakI7O0FBQ0EsVUFBSUEsTUFBTSxDQUFDYyxNQUFQLEdBQWdCLENBQXBCLEVBQXVCO0FBQ25CO0FBQ0E7QUFDQSxZQUFJLENBQUN6RSxLQUFLLENBQUNJLHVCQUFYLEVBQW9DO0FBQ2hDSyxVQUFBQSxHQUFHLENBQUNvQixVQUFKLENBQWVwQixHQUFHLENBQUNrQixVQUFKLEtBQW1CLEdBQW5CLEdBQXlCZ0MsTUFBTSxDQUFDLENBQUQsQ0FBL0IsR0FBcUMsR0FBckMsR0FBMkNoQixFQUEzQyxHQUFnRCxHQUEvRDtBQUNBM0MsVUFBQUEsS0FBSyxDQUFDSSx1QkFBTixHQUFnQyxJQUFoQztBQUNILFNBSEQsTUFHTztBQUNIO0FBQ0E7QUFDQSxjQUFJc0UsRUFBRSxHQUFHakUsR0FBRyxDQUFDa0IsVUFBSixFQUFUO0FBQ0ErQyxVQUFBQSxFQUFFLEdBQUdBLEVBQUUsQ0FBQ2hDLFNBQUgsQ0FBYSxDQUFiLEVBQWdCZ0MsRUFBRSxDQUFDQyxXQUFILENBQWUsR0FBZixDQUFoQixDQUFMO0FBQ0FELFVBQUFBLEVBQUUsSUFBSyxNQUFNZixNQUFNLENBQUMsQ0FBRCxDQUFaLEdBQWtCLEdBQWxCLEdBQXdCaEIsRUFBeEIsR0FBNkIsR0FBcEM7QUFDQWxDLFVBQUFBLEdBQUcsQ0FBQ29CLFVBQUosQ0FBZTZDLEVBQWY7QUFDSDtBQUNKLE9BaEJlLENBaUJoQjs7O0FBQ0ExRSxNQUFBQSxLQUFLLENBQUNRLFVBQU4sR0FBbUIsSUFBbkI7QUFDSDs7QUFDRFIsSUFBQUEsS0FBSyxDQUFDRyx3QkFBTixHQUFpQyxLQUFqQztBQUNILEdBaFdzQjs7QUFpV3ZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDSTBELEVBQUFBLGFBQWEsRUFBRSx1QkFBVWUsUUFBVixFQUFvQkMsTUFBcEIsRUFBNEI7QUFDdkM7QUFDQSxRQUFJcEUsR0FBRyxDQUFDSyxJQUFKLEtBQWEsQ0FBakIsRUFBb0I7QUFDaEJMLE1BQUFBLEdBQUcsQ0FBQ3FFLFdBQUo7QUFDSDs7QUFDRCxRQUFJbkMsRUFBRSxHQUFHbEMsR0FBRyxDQUFDWSxZQUFKLEVBQVQ7QUFBQSxRQUNJcUQsRUFBRSxHQUFHakUsR0FBRyxDQUFDa0IsVUFBSixFQURUOztBQUVBLFFBQUlsQixHQUFHLENBQUNzRSxRQUFKLENBQWFwQyxFQUFiLENBQUosRUFBc0I7QUFDbEI7QUFDQTNDLE1BQUFBLEtBQUssQ0FBQ0MsWUFBTixDQUFtQmlFLElBQW5CLENBQXdCdkIsRUFBeEIsRUFGa0IsQ0FHbEI7QUFDQTtBQUNBOztBQUNBbEMsTUFBQUEsR0FBRyxDQUFDb0IsVUFBSixDQUFlcEIsR0FBRyxDQUFDa0IsVUFBSixNQUFxQjNCLEtBQUssQ0FBQ0ksdUJBQU4sSUFBaUNzRSxFQUFFLENBQUNqQyxNQUFILENBQVVpQyxFQUFFLENBQUNELE1BQUgsR0FBWSxDQUF0QixNQUE2QixHQUEvRCxHQUM5QixNQUFNSSxNQUR3QixHQUNiLE1BQU1sQyxFQUFOLEdBQVcsR0FBWCxHQUFpQmtDLE1BRHhCLENBQWY7QUFFQSxVQUFJRyxLQUFLLEdBQUdoRixLQUFLLENBQUNFLGFBQU4sQ0FBb0IrRSxHQUFwQixFQUFaOztBQUNBLFVBQUlELEtBQUssSUFBSSxJQUFiLEVBQW1CO0FBQ2YsWUFBSUUsRUFBRSxHQUFHekUsR0FBRyxDQUFDeUIsZ0JBQUosQ0FBcUIwQyxRQUFyQixDQUFUO0FBQUEsWUFDSU8sRUFBRSxHQUFHMUUsR0FBRyxDQUFDeUIsZ0JBQUosQ0FBcUI4QyxLQUFyQixDQURULENBRGUsQ0FHZjs7QUFDQSxZQUFJRSxFQUFFLEdBQUdDLEVBQVQsRUFBYTtBQUNUbkYsVUFBQUEsS0FBSyxDQUFDRSxhQUFOLENBQW9CZ0UsSUFBcEIsQ0FBeUJjLEtBQXpCO0FBQ0gsU0FGRCxDQUdBO0FBSEEsYUFJSyxJQUFJRSxFQUFFLEdBQUcsQ0FBTCxJQUFVQSxFQUFFLEtBQUtDLEVBQXJCLEVBQXlCO0FBQzFCbkYsWUFBQUEsS0FBSyxDQUFDRSxhQUFOLENBQW9CZ0UsSUFBcEIsQ0FBeUJjLEtBQXpCO0FBQ0F2RSxZQUFBQSxHQUFHLENBQUMyRSxXQUFKLENBQWdCLENBQWhCO0FBQ0gsV0FISSxNQUdFO0FBQ0hwRixZQUFBQSxLQUFLLENBQUNFLGFBQU4sQ0FBb0JnRSxJQUFwQixDQUF5QmMsS0FBekI7QUFDQXZFLFlBQUFBLEdBQUcsQ0FBQ2dCLFlBQUosQ0FBaUJoQixHQUFHLENBQUMrRCxXQUFKLENBQWdCL0QsR0FBRyxDQUFDMkUsV0FBSixDQUFnQixJQUFoQixFQUFzQkYsRUFBdEIsQ0FBaEIsQ0FBakI7QUFDSDtBQUNKOztBQUNEbEYsTUFBQUEsS0FBSyxDQUFDRSxhQUFOLENBQW9CZ0UsSUFBcEIsQ0FBeUJVLFFBQXpCO0FBQ0g7O0FBQ0Q1RSxJQUFBQSxLQUFLLENBQUNJLHVCQUFOLEdBQWdDLEtBQWhDO0FBQ0FKLElBQUFBLEtBQUssQ0FBQ0ssZ0JBQU4sR0FBeUIsS0FBekI7QUFDSCxHQTFZc0I7O0FBMll2QjtBQUNKO0FBQ0E7QUFDSXlELEVBQUFBLFNBQVMsRUFBRSxxQkFBWTtBQUNuQixRQUFJLENBQUM5RCxLQUFLLENBQUNLLGdCQUFYLEVBQTZCO0FBQ3pCLFVBQUlzQyxFQUFFLEdBQUdsQyxHQUFHLENBQUNZLFlBQUosRUFBVDtBQUFBLFVBQ0lzQyxNQURKOztBQUVBLFVBQUlsRCxHQUFHLENBQUNzRSxRQUFKLENBQWFwQyxFQUFiLENBQUosRUFBc0I7QUFDbEIzQyxRQUFBQSxLQUFLLENBQUNDLFlBQU4sQ0FBbUJpRSxJQUFuQixDQUF3QnZCLEVBQXhCO0FBQ0FnQixRQUFBQSxNQUFNLEdBQUdsRCxHQUFHLENBQUMrRCxXQUFKLENBQWdCL0QsR0FBRyxDQUFDMkUsV0FBSixFQUFoQixDQUFUO0FBQ0EzRSxRQUFBQSxHQUFHLENBQUNnQixZQUFKLENBQWlCa0MsTUFBakI7QUFDQTNELFFBQUFBLEtBQUssQ0FBQ00sU0FBTixHQUFrQnFELE1BQWxCO0FBQ0FsRCxRQUFBQSxHQUFHLENBQUNvQixVQUFKLENBQWUsRUFBZixFQUxrQixDQU1sQjs7QUFDQSxZQUFJcEIsR0FBRyxDQUFDSyxJQUFKLEtBQWEsQ0FBakIsRUFBb0I7QUFDaEJMLFVBQUFBLEdBQUcsQ0FBQzZCLFVBQUosQ0FBZXFCLE1BQWY7QUFDSDs7QUFDRDNELFFBQUFBLEtBQUssQ0FBQ1EsVUFBTixHQUFtQixJQUFuQjtBQUNIOztBQUNEQyxNQUFBQSxHQUFHLENBQUM0RSxNQUFKOztBQUNBckYsTUFBQUEsS0FBSyxDQUFDSyxnQkFBTixHQUF5QixJQUF6QjtBQUNIO0FBQ0osR0FqYXNCOztBQWthdkI7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0krRSxFQUFBQSxXQUFXLEVBQUUscUJBQVVFLEtBQVYsRUFBaUJDLE1BQWpCLEVBQXlCO0FBQ2xDLFFBQUlMLEVBQUo7QUFBQSxRQUFRTSxDQUFSO0FBQUEsUUFBV0MsQ0FBWDtBQUFBLFFBQ0k7QUFDQTlCLElBQUFBLE1BQU0sR0FBRzNELEtBQUssQ0FBQ0MsWUFBTixDQUFtQkQsS0FBSyxDQUFDQyxZQUFOLENBQW1Cd0UsTUFBbkIsR0FBNEIsQ0FBL0MsQ0FGYjtBQUFBLFFBR0lpQixDQUFDLEdBQUdKLEtBQUssSUFBSXRGLEtBQUssQ0FBQ0UsYUFBTixDQUFvQnVFLE1BSHJDO0FBQUEsUUFJSWtCLENBQUMsR0FBR0osTUFBTSxJQUFJLENBSmxCOztBQUtBLFNBQUssSUFBSUssQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0YsQ0FBcEIsRUFBdUIsRUFBRUUsQ0FBekIsRUFBNEI7QUFDeEJWLE1BQUFBLEVBQUUsR0FBR2xGLEtBQUssQ0FBQ0UsYUFBTixDQUFvQitFLEdBQXBCLEVBQUwsQ0FEd0IsQ0FFeEI7O0FBQ0EsVUFBSXhFLEdBQUcsQ0FBQ3lCLGdCQUFKLENBQXFCZ0QsRUFBckIsSUFBMkJTLENBQTNCLElBQWdDVCxFQUFFLEtBQUssR0FBM0MsRUFBZ0Q7QUFDNUNsRixRQUFBQSxLQUFLLENBQUNFLGFBQU4sQ0FBb0JnRSxJQUFwQixDQUF5QmdCLEVBQXpCO0FBQ0E7QUFDSDs7QUFDRE8sTUFBQUEsQ0FBQyxHQUFHekYsS0FBSyxDQUFDQyxZQUFOLENBQW1CZ0YsR0FBbkIsRUFBSjtBQUNBTyxNQUFBQSxDQUFDLEdBQUd4RixLQUFLLENBQUNDLFlBQU4sQ0FBbUJnRixHQUFuQixFQUFKO0FBQ0F0QixNQUFBQSxNQUFNLEdBQUdsRCxHQUFHLENBQUNvRixZQUFKLENBQWlCTCxDQUFqQixFQUFvQkMsQ0FBcEIsRUFBdUJQLEVBQXZCLENBQVQ7QUFDQWxGLE1BQUFBLEtBQUssQ0FBQ0MsWUFBTixDQUFtQmlFLElBQW5CLENBQXdCUCxNQUF4QjtBQUNIOztBQUNELFdBQU9BLE1BQVA7QUFDSCxHQTlic0I7O0FBK2J2QjtBQUNKO0FBQ0E7QUFDSVEsRUFBQUEsUUFBUSxFQUFFLG9CQUFZO0FBQ2xCLFFBQUl4QixFQUFFLEdBQUdsQyxHQUFHLENBQUNZLFlBQUosRUFBVDs7QUFDQSxRQUFJWixHQUFHLENBQUNzRSxRQUFKLENBQWFwQyxFQUFiLENBQUosRUFBc0I7QUFDbEJsQyxNQUFBQSxHQUFHLENBQUNvQixVQUFKLENBQWVwQixHQUFHLENBQUNrQixVQUFKLE1BQW9CLE1BQU1nQixFQUFOLEdBQVcsSUFBL0IsQ0FBZjtBQUNBM0MsTUFBQUEsS0FBSyxDQUFDQyxZQUFOLENBQW1CaUUsSUFBbkIsQ0FBd0J2QixFQUF4QixFQUZrQixDQUdsQjs7QUFDQSxVQUFJdUMsRUFBRSxHQUFHbEYsS0FBSyxDQUFDRSxhQUFOLENBQW9CK0UsR0FBcEIsRUFBVDtBQUFBLFVBQ0lPLENBREo7QUFBQSxVQUNPQyxDQURQO0FBQUEsVUFDVTlCLE1BRFY7O0FBRUEsYUFBT3VCLEVBQUUsS0FBSyxHQUFQLElBQWNBLEVBQUUsSUFBSSxJQUEzQixFQUFpQztBQUM3Qk8sUUFBQUEsQ0FBQyxHQUFHekYsS0FBSyxDQUFDQyxZQUFOLENBQW1CZ0YsR0FBbkIsRUFBSjtBQUNBTyxRQUFBQSxDQUFDLEdBQUd4RixLQUFLLENBQUNDLFlBQU4sQ0FBbUJnRixHQUFuQixFQUFKO0FBQ0F0QixRQUFBQSxNQUFNLEdBQUdsRCxHQUFHLENBQUNvRixZQUFKLENBQWlCTCxDQUFqQixFQUFvQkMsQ0FBcEIsRUFBdUJQLEVBQXZCLENBQVQ7QUFDQWxGLFFBQUFBLEtBQUssQ0FBQ0MsWUFBTixDQUFtQmlFLElBQW5CLENBQXdCUCxNQUF4QjtBQUNBdUIsUUFBQUEsRUFBRSxHQUFHbEYsS0FBSyxDQUFDRSxhQUFOLENBQW9CK0UsR0FBcEIsRUFBTDtBQUNILE9BWmlCLENBYWxCO0FBQ0E7OztBQUNBeEUsTUFBQUEsR0FBRyxDQUFDZ0IsWUFBSixDQUFpQmhCLEdBQUcsQ0FBQytELFdBQUosQ0FBZ0J4RSxLQUFLLENBQUNDLFlBQU4sQ0FBbUJnRixHQUFuQixFQUFoQixDQUFqQjtBQUNIO0FBQ0osR0FyZHNCOztBQXNkdkI7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJWSxFQUFBQSxZQUFZLEVBQUUsc0JBQVVMLENBQVYsRUFBYUMsQ0FBYixFQUFnQlAsRUFBaEIsRUFBb0I7QUFDOUIsUUFBSXZCLE1BQUo7O0FBQ0EsUUFBSXVCLEVBQUUsS0FBSyxHQUFYLEVBQWdCO0FBQ1p2QixNQUFBQSxNQUFNLEdBQUdmLElBQUksQ0FBQ0UsR0FBTCxDQUFTMEMsQ0FBVCxFQUFZQyxDQUFaLENBQVQ7QUFDSCxLQUZELE1BRU8sSUFBSVAsRUFBRSxLQUFLLE9BQVgsRUFBb0I7QUFDdkJ2QixNQUFBQSxNQUFNLEdBQUdmLElBQUksQ0FBQ0UsR0FBTCxDQUFTMEMsQ0FBVCxFQUFZLElBQUlDLENBQWhCLENBQVQ7QUFDSCxLQUZNLENBR1A7QUFITyxTQUlGO0FBQ0Q7QUFDQSxZQUFJaEYsR0FBRyxDQUFDSyxJQUFKLEtBQWEsQ0FBakIsRUFBb0I7QUFDaEIsY0FBSWdGLEtBQUssR0FBRzlGLEtBQUssQ0FBQ08sWUFBbEI7QUFBQSxjQUNJd0YsRUFESjtBQUFBLGNBQ1FwRCxFQURSOztBQUVBLGNBQUltRCxLQUFLLEtBQUssRUFBZCxFQUFrQjtBQUNkbkMsWUFBQUEsTUFBTSxHQUFHQyxJQUFJLENBQUM0QixDQUFDLEdBQUdOLEVBQUosR0FBU08sQ0FBVixDQUFiO0FBQ0gsV0FGRCxNQUVPLElBQUlLLEtBQUssS0FBSyxFQUFkLEVBQWtCO0FBQ3JCQyxZQUFBQSxFQUFFLEdBQUcxRCxRQUFRLENBQUNtRCxDQUFELEVBQUksRUFBSixDQUFiO0FBQ0E3QyxZQUFBQSxFQUFFLEdBQUdOLFFBQVEsQ0FBQ29ELENBQUQsRUFBSSxFQUFKLENBQWI7QUFDQTlCLFlBQUFBLE1BQU0sR0FBR0MsSUFBSSxDQUFDbUMsRUFBRSxHQUFHYixFQUFMLEdBQVV2QyxFQUFYLENBQUosQ0FBbUJxRCxRQUFuQixDQUE0QixFQUE1QixDQUFUO0FBQ0gsV0FKTSxNQUlBLElBQUlGLEtBQUssS0FBSyxDQUFkLEVBQWlCO0FBQ3BCQyxZQUFBQSxFQUFFLEdBQUcxRCxRQUFRLENBQUNtRCxDQUFELEVBQUksQ0FBSixDQUFiO0FBQ0E3QyxZQUFBQSxFQUFFLEdBQUdOLFFBQVEsQ0FBQ29ELENBQUQsRUFBSSxDQUFKLENBQWI7QUFDQTlCLFlBQUFBLE1BQU0sR0FBR0MsSUFBSSxDQUFDbUMsRUFBRSxHQUFHYixFQUFMLEdBQVV2QyxFQUFYLENBQUosQ0FBbUJxRCxRQUFuQixDQUE0QixDQUE1QixDQUFUO0FBQ0gsV0FKTSxNQUlBO0FBQ0hELFlBQUFBLEVBQUUsR0FBRzFELFFBQVEsQ0FBQ21ELENBQUQsRUFBSSxDQUFKLENBQWI7QUFDQTdDLFlBQUFBLEVBQUUsR0FBR04sUUFBUSxDQUFDb0QsQ0FBRCxFQUFJLENBQUosQ0FBYjtBQUNBOUIsWUFBQUEsTUFBTSxHQUFHQyxJQUFJLENBQUNtQyxFQUFFLEdBQUdiLEVBQUwsR0FBVXZDLEVBQVgsQ0FBSixDQUFtQnFELFFBQW5CLENBQTRCLENBQTVCLENBQVQ7QUFDSDtBQUNKLFNBbEJELE1Ba0JPO0FBQ0hyQyxVQUFBQSxNQUFNLEdBQUdDLElBQUksQ0FBQzRCLENBQUMsR0FBR04sRUFBSixHQUFTTyxDQUFWLENBQWI7QUFDSDtBQUNKOztBQUNELFdBQU85QixNQUFQO0FBQ0gsR0EvZnNCOztBQWdnQnZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0lhLEVBQUFBLFdBQVcsRUFBRSxxQkFBVTlDLEtBQVYsRUFBaUI7QUFDMUIsUUFBSXVFLFFBQVEsR0FBR3ZFLEtBQUssR0FBRyxFQUF2Qjs7QUFDQSxRQUFJakIsR0FBRyxDQUFDc0MsT0FBSixDQUFZa0QsUUFBWixDQUFKLEVBQTJCO0FBQ3ZCQSxNQUFBQSxRQUFRLEdBQUdBLFFBQVEsQ0FBQ0MsT0FBVCxDQUFpQixLQUFqQixFQUF3QixFQUF4QixDQUFYO0FBQ0g7O0FBQ0QsV0FBT0QsUUFBUSxDQUFDeEIsTUFBVCxHQUFrQixFQUFsQixHQUF1Qi9DLEtBQUssQ0FBQ3dCLGFBQU4sQ0FBb0IsQ0FBcEIsQ0FBdkIsR0FBZ0QrQyxRQUF2RDtBQUNILEdBMWdCc0I7QUEyZ0J2QjtBQUNBbEMsRUFBQUEsRUFBRSxFQUFFLGNBQVk7QUFDWnRELElBQUFBLEdBQUcsQ0FBQ2dCLFlBQUosQ0FBaUIsR0FBakI7O0FBQ0EsUUFBSWhCLEdBQUcsQ0FBQ0ssSUFBSixLQUFhLENBQWpCLEVBQW9CO0FBQ2hCTCxNQUFBQSxHQUFHLENBQUNxRSxXQUFKO0FBQ0g7QUFDSixHQWpoQnNCO0FBa2hCdkI7QUFDQWQsRUFBQUEsS0FBSyxFQUFFLGlCQUFZO0FBQ2Z2RCxJQUFBQSxHQUFHLENBQUNnQixZQUFKLENBQWlCLEdBQWpCO0FBQ0FoQixJQUFBQSxHQUFHLENBQUNvQixVQUFKLENBQWUsRUFBZjs7QUFDQXBCLElBQUFBLEdBQUcsQ0FBQzRFLE1BQUo7O0FBQ0EsUUFBSTVFLEdBQUcsQ0FBQ0ssSUFBSixLQUFhLENBQWpCLEVBQW9CO0FBQ2hCTCxNQUFBQSxHQUFHLENBQUNxRSxXQUFKO0FBQ0g7QUFDSixHQTFoQnNCOztBQTJoQnZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0lBLEVBQUFBLFdBQVcsRUFBRSx1QkFBWTtBQUNyQixTQUFLLElBQUljLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsQ0FBcEIsRUFBdUJBLENBQUMsRUFBeEIsRUFBNEI7QUFDeEJuRixNQUFBQSxHQUFHLENBQUNRLEtBQUosQ0FBVUcsVUFBVixDQUFxQndFLENBQXJCLEVBQXdCcEUsTUFBeEIsR0FBaUMsR0FBakM7QUFDSDtBQUNKLEdBbmlCc0I7QUFvaUJ2QnlDLEVBQUFBLElBQUksRUFBRSxnQkFBWTtBQUNkLFFBQUl6QixRQUFRLEdBQUcvQixHQUFHLENBQUNZLFlBQUosRUFBZjtBQUNBWixJQUFBQSxHQUFHLENBQUNnQixZQUFKLENBQWlCZSxRQUFRLENBQUNpQyxNQUFULEdBQWtCLENBQWxCLEdBQXNCLEdBQXRCLEdBQTRCakMsUUFBUSxDQUFDRSxTQUFULENBQW1CLENBQW5CLEVBQXNCRixRQUFRLENBQUNpQyxNQUFULEdBQWtCLENBQXhDLENBQTdDO0FBQ0gsR0F2aUJzQjs7QUF3aUJ2QjtBQUNKO0FBQ0E7QUFDQTtBQUNJbkMsRUFBQUEsVUFBVSxFQUFFLG9CQUFVNkQsR0FBVixFQUFlO0FBQ3ZCLFFBQUl4QyxNQUFNLEdBQUdsRCxHQUFHLENBQUMyRixlQUFKLENBQW9CRCxHQUFwQixDQUFiO0FBQUEsUUFDSUUsS0FBSyxHQUFHNUYsR0FBRyxDQUFDUSxLQUFKLENBQVVHLFVBRHRCOztBQUVBLFNBQUssSUFBSXdFLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsQ0FBcEIsRUFBdUIsRUFBRUEsQ0FBekIsRUFBNEI7QUFDeEJTLE1BQUFBLEtBQUssQ0FBQ1QsQ0FBRCxDQUFMLENBQVNwRSxNQUFULEdBQWtCbUMsTUFBTSxDQUFDaUMsQ0FBRCxDQUF4QjtBQUNIO0FBQ0osR0FsakJzQjs7QUFtakJ2QjtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0lRLEVBQUFBLGVBQWUsRUFBRSx5QkFBVUQsR0FBVixFQUFlO0FBQzVCLFFBQUlMLEtBQUssR0FBRzlGLEtBQUssQ0FBQ08sWUFBbEI7QUFBQSxRQUNJb0QsTUFBTSxHQUFHLEVBRGI7QUFBQSxRQUVJaUMsQ0FGSjs7QUFHQSxRQUFJRSxLQUFLLEtBQUssRUFBZCxFQUFrQjtBQUNkRixNQUFBQSxDQUFDLEdBQUd2RCxRQUFRLENBQUM4RCxHQUFELENBQVo7QUFDQXhDLE1BQUFBLE1BQU0sQ0FBQyxDQUFELENBQU4sR0FBWWlDLENBQUMsQ0FBQ0ksUUFBRixDQUFXLEVBQVgsQ0FBWjtBQUNBckMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZaUMsQ0FBWjtBQUNBakMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZaUMsQ0FBQyxDQUFDSSxRQUFGLENBQVcsQ0FBWCxDQUFaO0FBQ0FyQyxNQUFBQSxNQUFNLENBQUMsQ0FBRCxDQUFOLEdBQVlpQyxDQUFDLENBQUNJLFFBQUYsQ0FBVyxDQUFYLENBQVo7QUFDSCxLQU5ELE1BTU8sSUFBSUYsS0FBSyxLQUFLLEVBQWQsRUFBa0I7QUFDckI7QUFDQUYsTUFBQUEsQ0FBQyxHQUFHdkQsUUFBUSxDQUFDOEQsR0FBRCxFQUFNLEVBQU4sQ0FBWjtBQUNBeEMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZd0MsR0FBWjtBQUNBeEMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZaUMsQ0FBWjtBQUNBakMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZaUMsQ0FBQyxDQUFDSSxRQUFGLENBQVcsQ0FBWCxDQUFaO0FBQ0FyQyxNQUFBQSxNQUFNLENBQUMsQ0FBRCxDQUFOLEdBQVlpQyxDQUFDLENBQUNJLFFBQUYsQ0FBVyxDQUFYLENBQVo7QUFDSCxLQVBNLE1BT0EsSUFBSUYsS0FBSyxLQUFLLENBQWQsRUFBaUI7QUFDcEJGLE1BQUFBLENBQUMsR0FBR3ZELFFBQVEsQ0FBQzhELEdBQUQsRUFBTSxDQUFOLENBQVo7QUFDQXhDLE1BQUFBLE1BQU0sQ0FBQyxDQUFELENBQU4sR0FBWWlDLENBQUMsQ0FBQ0ksUUFBRixDQUFXLEVBQVgsQ0FBWjtBQUNBckMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZaUMsQ0FBWjtBQUNBakMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZd0MsR0FBWjtBQUNBeEMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZaUMsQ0FBQyxDQUFDSSxRQUFGLENBQVcsQ0FBWCxDQUFaO0FBQ0gsS0FOTSxNQU1BO0FBQ0hKLE1BQUFBLENBQUMsR0FBR3ZELFFBQVEsQ0FBQzhELEdBQUQsRUFBTSxDQUFOLENBQVo7QUFDQXhDLE1BQUFBLE1BQU0sQ0FBQyxDQUFELENBQU4sR0FBWWlDLENBQUMsQ0FBQ0ksUUFBRixDQUFXLEVBQVgsQ0FBWjtBQUNBckMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZaUMsQ0FBWjtBQUNBakMsTUFBQUEsTUFBTSxDQUFDLENBQUQsQ0FBTixHQUFZaUMsQ0FBQyxDQUFDSSxRQUFGLENBQVcsQ0FBWCxDQUFaO0FBQ0FyQyxNQUFBQSxNQUFNLENBQUMsQ0FBRCxDQUFOLEdBQVl3QyxHQUFaO0FBQ0g7O0FBQ0QsV0FBT3hDLE1BQVA7QUFDSCxHQXZsQnNCOztBQXdsQnZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDSW9CLEVBQUFBLFFBQVEsRUFBRSxrQkFBVXVCLEdBQVYsRUFBZTtBQUNyQixXQUFPN0YsR0FBRyxDQUFDNEQsU0FBSixDQUFjaUMsR0FBZCxLQUFzQjdGLEdBQUcsQ0FBQ3NDLE9BQUosQ0FBWXVELEdBQVosQ0FBdEIsSUFBMEM3RixHQUFHLENBQUM2RCxZQUFKLENBQWlCZ0MsR0FBakIsQ0FBMUMsSUFBbUU3RixHQUFHLENBQUM4RixLQUFKLENBQVVELEdBQVYsQ0FBMUU7QUFDSCxHQS9sQnNCOztBQWdtQnZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0lqQyxFQUFBQSxTQUFTLEVBQUUsbUJBQVVpQyxHQUFWLEVBQWU7QUFDdEIsV0FBT0EsR0FBRyxDQUFDRSxLQUFKLENBQVUvRixHQUFHLENBQUNxQixVQUFkLENBQVA7QUFDSCxHQXRtQnNCOztBQXVtQnZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0lpQixFQUFBQSxPQUFPLEVBQUUsaUJBQVV1RCxHQUFWLEVBQWU7QUFDcEIsV0FBT0EsR0FBRyxDQUFDRSxLQUFKLENBQVUvRixHQUFHLENBQUNzQixZQUFkLENBQVA7QUFDSCxHQTdtQnNCOztBQThtQnZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0l1QyxFQUFBQSxZQUFZLEVBQUUsc0JBQVVnQyxHQUFWLEVBQWU7QUFDekIsV0FBT0EsR0FBRyxDQUFDRSxLQUFKLENBQVUvRixHQUFHLENBQUN1QixpQkFBZCxDQUFQO0FBQ0gsR0FwbkJzQjs7QUFxbkJ2QjtBQUNKO0FBQ0E7QUFDQTtBQUNJdUUsRUFBQUEsS0FBSyxFQUFFLGVBQVVELEdBQVYsRUFBZTtBQUNsQixXQUFPQSxHQUFHLENBQUNFLEtBQUosQ0FBVS9GLEdBQUcsQ0FBQ3dCLFVBQWQsQ0FBUDtBQUNILEdBM25Cc0I7O0FBNG5CdkI7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNJZixFQUFBQSxTQUFTLEVBQUUsbUJBQVVRLEtBQVYsRUFBaUI7QUFDeEIsUUFBSWMsUUFBUSxHQUFHL0IsR0FBRyxDQUFDWSxZQUFKLEVBQWY7QUFDQSxRQUFJb0YsUUFBUSxHQUFHakUsUUFBZjs7QUFDQSxRQUFJeEMsS0FBSyxDQUFDUSxVQUFWLEVBQXNCO0FBQ2xCO0FBQ0EsVUFBSWtCLEtBQUssS0FBSyxHQUFkLEVBQW1CO0FBQ2YrRSxRQUFBQSxRQUFRLEdBQUcsSUFBWDtBQUNILE9BRkQsTUFFTztBQUNIQSxRQUFBQSxRQUFRLEdBQUcvRSxLQUFYO0FBQ0g7QUFDSixLQVBELE1BT08sSUFBSWMsUUFBUSxDQUFDaUMsTUFBVCxHQUFrQixFQUF0QixFQUEwQjtBQUM3QixVQUFJakMsUUFBUSxLQUFLLEdBQWpCLEVBQXNCO0FBQ2xCLFlBQUlkLEtBQUssS0FBSyxHQUFkLEVBQW1CO0FBQ2YrRSxVQUFBQSxRQUFRLEdBQUcsSUFBWDtBQUNILFNBRkQsTUFFTztBQUNIQSxVQUFBQSxRQUFRLEdBQUcvRSxLQUFYO0FBQ0g7QUFDSixPQU5ELE1BTU87QUFDSCtFLFFBQUFBLFFBQVEsSUFBSS9FLEtBQVo7QUFDSDtBQUNKOztBQUNEakIsSUFBQUEsR0FBRyxDQUFDZ0IsWUFBSixDQUFpQmdGLFFBQWpCO0FBQ0F6RyxJQUFBQSxLQUFLLENBQUNRLFVBQU4sR0FBbUIsS0FBbkI7QUFDQVIsSUFBQUEsS0FBSyxDQUFDRyx3QkFBTixHQUFpQyxLQUFqQztBQUNBSCxJQUFBQSxLQUFLLENBQUNJLHVCQUFOLEdBQWdDLEtBQWhDO0FBQ0FKLElBQUFBLEtBQUssQ0FBQ0ssZ0JBQU4sR0FBeUIsS0FBekI7QUFDSCxHQTNwQnNCOztBQTRwQnZCO0FBQ0o7QUFDQTtBQUNBO0FBQ0lxRyxFQUFBQSxVQUFVLEVBQUUsb0JBQVU1RixJQUFWLEVBQWdCO0FBQ3hCO0FBQ0EsUUFBSTZGLFNBQVMsR0FBR2xHLEdBQUcsQ0FBQ00sVUFBSixDQUFlTixHQUFHLENBQUNLLElBQW5CLENBQWhCO0FBQ0E4RixJQUFBQSxRQUFRLENBQUNDLGNBQVQsQ0FBd0JGLFNBQVMsR0FBRyxVQUFwQyxFQUFnREcsS0FBaEQsQ0FBc0RDLE9BQXRELEdBQWdFLE1BQWhFLENBSHdCLENBSXhCOztBQUNBSCxJQUFBQSxRQUFRLENBQUNDLGNBQVQsQ0FBd0JGLFNBQVMsR0FBRyxNQUFwQyxFQUE0Q0csS0FBNUMsQ0FBa0RDLE9BQWxELEdBQTRELE1BQTVEO0FBQ0FILElBQUFBLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QnBHLEdBQUcsQ0FBQ00sVUFBSixDQUFlRCxJQUFmLElBQXVCLE1BQS9DLEVBQXVEZ0csS0FBdkQsQ0FBNkRDLE9BQTdELEdBQXVFLE9BQXZFO0FBQ0F0RyxJQUFBQSxHQUFHLENBQUNLLElBQUosR0FBV0EsSUFBWDs7QUFDQSxRQUFJLENBQUNMLEdBQUcsQ0FBQ08sU0FBSixDQUFjRixJQUFkLENBQUwsRUFBMEI7QUFDdEJMLE1BQUFBLEdBQUcsQ0FBQ3VHLGFBQUo7QUFDQXZHLE1BQUFBLEdBQUcsQ0FBQ08sU0FBSixDQUFjRixJQUFkLElBQXNCLElBQXRCO0FBQ0g7O0FBQ0RMLElBQUFBLEdBQUcsQ0FBQ3dHLFNBQUo7O0FBQ0F4RyxJQUFBQSxHQUFHLENBQUM0RSxNQUFKO0FBQ0gsR0E5cUJzQjs7QUErcUJ2QjtBQUNKO0FBQ0E7QUFDQTtBQUNJQSxFQUFBQSxNQUFNLEVBQUUsa0JBQVk7QUFDaEJyRixJQUFBQSxLQUFLLENBQUNDLFlBQU4sR0FBcUIsRUFBckI7QUFDQUQsSUFBQUEsS0FBSyxDQUFDRSxhQUFOLEdBQXNCLEVBQXRCO0FBQ0FGLElBQUFBLEtBQUssQ0FBQ0csd0JBQU4sR0FBaUMsS0FBakM7QUFDQUgsSUFBQUEsS0FBSyxDQUFDSSx1QkFBTixHQUFnQyxLQUFoQztBQUNBSixJQUFBQSxLQUFLLENBQUNLLGdCQUFOLEdBQXlCLEtBQXpCO0FBQ0g7QUF6ckJzQixDQUFkLENBQWIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG53aW5kb3cubV9jYWwgPSB7XHJcbiAgICAvL+aTjeS9nOaVsOagiFxyXG4gICAgb3BlcmFuZFN0YWNrOiBbXSxcclxuICAgIC8v6L+Q566X56ym5qCIXHJcbiAgICBvcGVyYXRvclN0YWNrOiBbXSxcclxuICAgIC8v5LiK5LiA5qyh6L6T5YWl5piv5ZCm5piv5LqM5YWD6L+Q566X56ym77yM5aaC5p6c5piv5bm25LiU5YaN5qyh6L6T5YWl5LqM5YWD6L+Q566X56ym77yM6YKj5LmI5b+955Wl5q2k5qyh6L6T5YWlXHJcbiAgICBpc1ByZUlucHV0QmluYXJ5T3BlcmF0b3I6IGZhbHNlLFxyXG4gICAgLy/kuIrmrKHmjInplK7mmK/lkKbmmK/kuIDlhYPmk43kvZxcclxuICAgIGlzUHJlSW5wdXRVbmFyeU9wZXJhdG9yOiBmYWxzZSxcclxuICAgIC8v562J5Y+35LiN5Y+v5Lul6L+e5oyJXHJcbiAgICBpc1ByZUlucHV0RXF1YWxzOiBmYWxzZSxcclxuICAgIC8v5aaC5p6c5Li6dHJ1Ze+8jOmCo+S5iOaOpeS4i+adpei+k+WFpeeahOaVsOWtl+mcgOimgeimhuebluWcqHNob3dJbnB1dOS4iu+8jOiAjOS4jeaYr+i/veWKoFxyXG4gICAgLy/kuIrkuIDmrKHorqHnrpfnmoTnu5PmnpwoPSlcclxuICAgIHByZVJlc3VsdDogMCxcclxuICAgIC8v5b2T5YmN5L2/55So55qE6L+b5Yi2KOWPquWcqOeoi+W6j+WRmOS4reacieaViCks6buY6K6kMTDov5vliLYoREVDKVxyXG4gICAgY3VycmVudFNjYWxlOiAxMCxcclxuICAgIGlzT3ZlcnJpZGU6IGZhbHNlLFxyXG59XHJcblxyXG4vL3RvZG9cclxud2luZG93LmNhbCA9IE9iamVjdC5mcmVlemUoe1xyXG4gICAgLy/orqHnrpflmajmjInplK7nvJbnoIFcclxuICAgIGtleUNvZGVzOiB7XHJcbiAgICAgICAgMDogJzAnLFxyXG4gICAgICAgIDE6ICcxJyxcclxuICAgICAgICAyOiAnMicsXHJcbiAgICAgICAgMzogJzMnLFxyXG4gICAgICAgIDQ6ICc0JyxcclxuICAgICAgICA1OiAnNScsXHJcbiAgICAgICAgNjogJzYnLFxyXG4gICAgICAgIDc6ICc3JyxcclxuICAgICAgICA4OiAnOCcsXHJcbiAgICAgICAgOTogJzknLFxyXG4gICAgICAgIDEwOiAnLicsXHJcbiAgICAgICAgMTE6ICfCsScsXHJcbiAgICAgICAgMTI6ICc9JyxcclxuICAgICAgICAxMzogJysnLFxyXG4gICAgICAgIDE0OiAnLScsXHJcbiAgICAgICAgMTU6ICcqJyxcclxuICAgICAgICAxNjogJy8nLFxyXG4gICAgICAgIDE3OiAnJScsXHJcbiAgICAgICAgMTg6ICfiiJonLFxyXG4gICAgICAgIDE5OiAneDInLFxyXG4gICAgICAgIDIwOiAnMS94JyxcclxuICAgICAgICAyMTogJygnLFxyXG4gICAgICAgIDIyOiAnKScsXHJcbiAgICAgICAgMjM6ICd5cm9vdCcsXHJcbiAgICAgICAgMjQ6ICduIScsXHJcbiAgICAgICAgMjU6ICdFeHAnLFxyXG4gICAgICAgIDI2OiAnXicsXHJcbiAgICAgICAgMjc6ICdzaW4nLFxyXG4gICAgICAgIDI4OiAnY29zJyxcclxuICAgICAgICAyOTogJ3RhbicsXHJcbiAgICAgICAgMzA6ICdwb3d0ZW4nLFxyXG4gICAgICAgIDMxOiAnbG9nJyxcclxuICAgICAgICAzMjogJ3NpbmgnLFxyXG4gICAgICAgIDMzOiAnY29zaCcsXHJcbiAgICAgICAgMzQ6ICd0YW5oJyxcclxuICAgICAgICAzNTogJ8+AJyxcclxuICAgICAgICAzNjogJ+KGkScsXHJcbiAgICAgICAgMzc6ICdDRScsXHJcbiAgICAgICAgMzg6ICdDJyxcclxuICAgICAgICAzOTogJ0JhY2snLFxyXG4gICAgICAgIC8v5Lul5LiL5piv56iL5bqP5ZGY5Z6L54m55pyJ55qE5oyJ6ZSuXHJcbiAgICAgICAgNDA6ICdBJyxcclxuICAgICAgICA0MTogJ0InLFxyXG4gICAgICAgIDQyOiAnQycsXHJcbiAgICAgICAgNDM6ICdEJyxcclxuICAgICAgICA0NDogJ0UnLFxyXG4gICAgICAgIDQ1OiAnRicsXHJcbiAgICAgICAgNDY6ICcmJyxcclxuICAgICAgICA0NzogJ3wnLFxyXG4gICAgICAgIDQ4OiAnfidcclxuICAgIH0sXHJcbiAgICAvL+aYoOWwhOeUqOS6juaYvuekuueahOaTjeS9nOespu+8jOavlOWmguiuoeeul+aXtueUqCrvvIzogIzmmL7npLrml7Z45pu05aW9XHJcbiAgICBvcGVyYXRvckZhY2FkZToge1xyXG4gICAgICAgIDEzOiAnKycsXHJcbiAgICAgICAgMTQ6ICctJyxcclxuICAgICAgICAxNTogJ8OXJyxcclxuICAgICAgICAxNjogJ8O3JyxcclxuICAgICAgICAxNzogJyUnLFxyXG4gICAgICAgIDIzOiAneXJvb3QnLFxyXG4gICAgICAgIDI2OiAnXicsXHJcbiAgICAgICAgNDY6ICcmJyxcclxuICAgICAgICA0NzogJ3wnXHJcbiAgICB9LFxyXG4gICAgLy/lvZPliY3orqHnrpflmajnmoTnsbvlnosxIC0tPiDmoIflh4blnossIDItLT7np5HlrablnovvvIwgMy0tPueoi+W6j+WRmOWei++8jOm7mOiupOagh+WHhuWei1xyXG4gICAgdHlwZTogMSxcclxuICAgIC8v6K6h566X5Zmo57G75Z6L5YmN57yA77yM55So5LqO5LuO6aG16Z2i6I635Y+W5YWD57SgXHJcbiAgICB0eXBlUHJlZml4OiB7XHJcbiAgICAgICAgMTogXCJzdGQtXCIsXHJcbiAgICAgICAgMjogXCJzY2ktXCIsXHJcbiAgICAgICAgMzogXCJwcm8tXCJcclxuICAgIH0sXHJcbiAgICAvL+iusOW9leavj+S4quexu+Wei+eahOiuoeeul+WZqOeahOS6i+S7tuebkeWQrOaYr+WQpuW3sue7j+e7keWumixrZXk6dHlwcGXmlbDlgLzvvIx2YWx1ZTrpu5jorqTmoIflh4blnovmmK90cnVlKOW3suWKoOi9vSlcclxuICAgIGhhc0luaXRlZDoge1xyXG4gICAgICAgIDE6IHRydWUsXHJcbiAgICAgICAgMjogZmFsc2UsXHJcbiAgICAgICAgMzogZmFsc2VcclxuICAgIH0sXHJcbiAgICBjYWNoZToge1xyXG4gICAgICAgIC8v6L6T5YWl5YaF5a655pi+56S65YWD57SgXHJcbiAgICAgICAgc2hvd0lucHV0OiBudWxsLFxyXG4gICAgICAgIC8v5LiK5LiA5q2l6K6h566X57uT5p6c5pi+56S65Yy65Z+fXHJcbiAgICAgICAgcHJlU3RlcDogbnVsbCxcclxuICAgICAgICAvL+aYvuekuuWbm+enjei/m+WItuaVsOWAvOeahHNwYW7vvIzlj6rlnKjnqIvluo/lkZjlnovmnInmlYhcclxuICAgICAgICBzY2FsZVNwYW5zOiBudWxsXHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiDojrflj5ZjYWNoZS5zaG93SW5wdXTnmoTlhoXlrrlcclxuICAgICAqIEByZXR1cm4gU3RyaW5nXHJcbiAgICAgKi9cclxuICAgIGdldFNob3dJbnB1dDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBzdGQubGJfc2hvd0lucHV0LnN0cmluZztcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOiuvue9rnNob3dJbnB1dOeahOWAvFxyXG4gICAgICogQHBhcmFtIHZhbHVlXHJcbiAgICAgKi9cclxuICAgIHNldFNob3dJbnB1dDogZnVuY3Rpb24gKHZhbHVlKSB7XHJcbiAgICAgICAgc3RkLmxiX3Nob3dJbnB1dC5zdHJpbmcgPSB2YWx1ZTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOiOt+WPlmNhY2hlLnByZVN0ZXDnmoTlhoXlrrlcclxuICAgICAqIEByZXR1cm4gU3RyaW5nXHJcbiAgICAgKi9cclxuICAgIGdldFByZVN0ZXA6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gc3RkLmxiX3ByZVN0ZXAuc3RyaW5nO1xyXG4gICAgfSxcclxuICAgIHNldFByZVN0ZXA6IGZ1bmN0aW9uICh2YWx1ZSkge1xyXG4gICAgICAgIHN0ZC5sYl9wcmVTdGVwLnN0cmluZyA9IHZhbHVlO1xyXG4gICAgfSxcclxuXHJcbiAgICAvL2ludOagoemqjFxyXG4gICAgaW50UGF0dGVybjogL14tP1xcZCskLyxcclxuICAgIC8v5bCP5pWw5qCh6aqMXHJcbiAgICBmbG9hdFBhdHRlcm46IC9eLT9cXGQrXFwuXFxkKyQvLFxyXG4gICAgLy/np5HlraborqHmlbDms5XmoKHpqoxcclxuICAgIHNjaWVudGlmaWNQYXR0ZXJuOiAvXlxcZCtcXC5cXGQrZShcXCt8LSlcXGQrJC8sXHJcbiAgICAvL+agoemqjDE26L+b5Yi25pWw5a2XXHJcbiAgICBoZXhQYXR0ZXJuOiAvXlswLTlBLUZdKyQvLFxyXG4gICAgLy/ovoXliqnliKTmlq3ov5DnrpfnrKbnmoTkvJjlhYjnuqdcclxuICAgIG9wZXJhdG9yUHJpb3JpdHk6IHtcclxuICAgICAgICBcIilcIjogMCxcclxuICAgICAgICBcInxcIjogMSxcclxuICAgICAgICBcIiZcIjogMixcclxuICAgICAgICBcIitcIjogMyxcclxuICAgICAgICBcIi1cIjogMyxcclxuICAgICAgICBcIipcIjogNCxcclxuICAgICAgICBcIiVcIjogNCxcclxuICAgICAgICBcIi9cIjogNCxcclxuICAgICAgICBcIl5cIjogNSxcclxuICAgICAgICBcInlyb290XCI6IDUsXHJcbiAgICAgICAgXCIoXCI6IDZcclxuICAgIH0sXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDnm7jlupTmjInplK7mjInkuIvkuovku7ZcclxuICAgICAqIEBwYXJhbSB2YWx1ZSDmjInplK7nmoR2YWx1ZeWAvCjljbPlhbZrZXlDb2RlKVxyXG4gICAgICovXHJcbiAgICBoYW5kbGVLZXk6IGZ1bmN0aW9uICh2YWx1ZSkge1xyXG4gICAgICAgIGxldCBrZXlDb2RlID0gcGFyc2VJbnQodmFsdWUpO1xyXG4gICAgICAgIC8v5aaC5p6c5piv5LiA5Liq5pWw5a2X5oiW6ICF5bCP5pWw54K577yM55u05o6l5pi+56S65Ye65p2lXHJcbiAgICAgICAgaWYgKGtleUNvZGUgPCAxMSB8fCAoa2V5Q29kZSA+IDM5ICYmIGtleUNvZGUgPCA0NikpIHtcclxuICAgICAgICAgICAgY2FsLnNob3dJbnB1dChjYWwua2V5Q29kZXNba2V5Q29kZV0pO1xyXG4gICAgICAgICAgICBpZiAoY2FsLnR5cGUgPT09IDMpIHtcclxuICAgICAgICAgICAgICAgIC8v5aaC5p6c5piv56iL5bqP5ZGY5Z6L77yM6YKj5LmI6ZyA6KaB5ZCM5q2l5pi+56S6NOS4rei/m+WItueahOWAvFxyXG4gICAgICAgICAgICAgICAgY2FsLnNob3dTY2FsZXMoY2FsLmdldFNob3dJbnB1dCgpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoa2V5Q29kZSkge1xyXG4gICAgICAgICAgICAgICAgLy/mraPotJ/lj7dcclxuICAgICAgICAgICAgICAgIGNhc2UgMTE6XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLnVuYXJ5T3BlcmF0ZShmdW5jdGlvbiAob2xkVmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2xkVmFsdWUgKz0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9sZFZhbHVlID09PSBcIjBcIikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtvbGRWYWx1ZV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9sZFZhbHVlLmNoYXJBdCgwKSA9PT0gJy0nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW29sZFZhbHVlLnN1YnN0cmluZygxKV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW1wiLVwiICsgb2xkVmFsdWVdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAvL+W8gOagueS4i1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxODpcclxuICAgICAgICAgICAgICAgICAgICBjYWwudW5hcnlPcGVyYXRlKGZ1bmN0aW9uIChzaSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW01hdGguc3FydChzaSksIFwic3FydFwiXTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIC8v5bmz5pa5XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE5OlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC51bmFyeU9wZXJhdGUoZnVuY3Rpb24gKHNpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbTWF0aC5wb3coc2ksIDIpLCBcInNxclwiXTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIC8v5Y+W5YCS5pWwXHJcbiAgICAgICAgICAgICAgICBjYXNlIDIwOlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC51bmFyeU9wZXJhdGUoZnVuY3Rpb24gKHNpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbc2kgPT09IDAgPyBcIjDkuI3og73kvZzooqvpmaTmlbBcIiA6IDEgLyBzaSwgXCIxL1wiXTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIC8v6Zi25LmYXHJcbiAgICAgICAgICAgICAgICBjYXNlIDI0OlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC51bmFyeU9wZXJhdGUoZnVuY3Rpb24gKHNpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzaSA8IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpID0gKDAgLSBzaSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNhbC5pc0Zsb2F0KHNpICsgXCJcIikpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpID0gTWF0aC5mbG9vcihzaSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtjYWwuZmFjdChzaSksIFwiZmFjdFwiXTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIC8vRXhwIOi9rOS4uuenkeWtpuiuoeaVsOazleihqOekulxyXG4gICAgICAgICAgICAgICAgY2FzZSAyNTpcclxuICAgICAgICAgICAgICAgICAgICBjYWwudW5hcnlPcGVyYXRlKGZ1bmN0aW9uIChzaSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW3NpLnRvRXhwb25lbnRpYWwoNyldO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy9zaW5cclxuICAgICAgICAgICAgICAgIGNhc2UgMjc6XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLnVuYXJ5T3BlcmF0ZShmdW5jdGlvbiAoc2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtNYXRoLnNpbihzaSksIFwic2luXCJdO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy9jb3NcclxuICAgICAgICAgICAgICAgIGNhc2UgMjg6XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLnVuYXJ5T3BlcmF0ZShmdW5jdGlvbiAoc2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtNYXRoLmNvcyhzaSksIFwiY29zXCJdO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy90YW5cclxuICAgICAgICAgICAgICAgIGNhc2UgMjk6XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLnVuYXJ5T3BlcmF0ZShmdW5jdGlvbiAoc2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtNYXRoLnRhbihzaSksIFwidGFuXCJdO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy8xMOeahHjmrKHmlrlcclxuICAgICAgICAgICAgICAgIGNhc2UgMzA6XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLnVuYXJ5T3BlcmF0ZShmdW5jdGlvbiAoc2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtNYXRoLnBvdygxMCwgc2kpLCBcInBvd3RlblwiXTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIC8vbG9nXHJcbiAgICAgICAgICAgICAgICBjYXNlIDMxOlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC51bmFyeU9wZXJhdGUoZnVuY3Rpb24gKHNpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vanPnmoRNYXRoLmxvZ+aYr2XnmoTlr7nmlbDvvIxXaW5kb3dz6K6h566X5Zmo5pivMTDnmoTlr7nmlbDvvIzmraTlpITlj4LogINXaW5kb3dzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbTWF0aC5sb2cxMChzaSksIFwibG9nXCJdO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy9zaW5oKOWPjOabsuato+W8puWHveaVsClcclxuICAgICAgICAgICAgICAgIGNhc2UgMzI6XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLnVuYXJ5T3BlcmF0ZShmdW5jdGlvbiAoc2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtNYXRoLnNpbmgoc2kpLCBcInNpbmhcIl07XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAvL2Nvc2go5Y+M5puy5L2Z5bym5Ye95pWwKVxyXG4gICAgICAgICAgICAgICAgY2FzZSAzMzpcclxuICAgICAgICAgICAgICAgICAgICBjYWwudW5hcnlPcGVyYXRlKGZ1bmN0aW9uIChzaSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW01hdGguY29zaChzaSksIFwiY29zaFwiXTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIC8vdGFuaCjlj4zmm7LkvZnliIflh73mlbApXHJcbiAgICAgICAgICAgICAgICBjYXNlIDM0OlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC51bmFyeU9wZXJhdGUoZnVuY3Rpb24gKHNpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbTWF0aC50YW5oKHNpKSwgXCJ0YW5oXCJdO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy/PgFxyXG4gICAgICAgICAgICAgICAgY2FzZSAzNTpcclxuICAgICAgICAgICAgICAgICAgICBjYWwudW5hcnlPcGVyYXRlKGZ1bmN0aW9uIChzaSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW01hdGguUEldO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy/mjInkvY3lj5blj40ofilcclxuICAgICAgICAgICAgICAgIGNhc2UgNDg6XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLnVuYXJ5T3BlcmF0ZShmdW5jdGlvbiAoc2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3VsdCA9IGV2YWwoXCJ+XCIgKyBzaSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8v5pi+56S65Zub56eN6L+b5Yi255qE5pWw5YC8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbC5zaG93U2NhbGVzKHJlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbcmVzdWx0XTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIC8v5LqM5YWD6L+Q566X56ym5byA5aeLXHJcbiAgICAgICAgICAgICAgICAvL+WKoOOAgeWHj+OAgeS5mOOAgemZpOOAgeWPluS9me+8jOi/kOeul+avlOi+g+eugOWNle+8jOebtOaOpeWIqeeUqGV2YWzljbPlj6/msYLlgLxcclxuICAgICAgICAgICAgICAgIGNhc2UgMTM6XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE0OlxyXG4gICAgICAgICAgICAgICAgY2FzZSAxNTpcclxuICAgICAgICAgICAgICAgIGNhc2UgMTY6XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE3OlxyXG4gICAgICAgICAgICAgICAgLy9455qEeeasoeaWuVxyXG4gICAgICAgICAgICAgICAgY2FzZSAyNjpcclxuICAgICAgICAgICAgICAgIC8v5byA5Lu75oSP5qyh5pa55qC5XHJcbiAgICAgICAgICAgICAgICBjYXNlIDIzOlxyXG4gICAgICAgICAgICAgICAgLy9BbmQgT3JcclxuICAgICAgICAgICAgICAgIGNhc2UgNDY6XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ3OlxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChtX2NhbC5pc1ByZUlucHV0QmluYXJ5T3BlcmF0b3IpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG1fY2FsLmlzUHJlSW5wdXRCaW5hcnlPcGVyYXRvciA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgbV9jYWwuaXNPdmVycmlkZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLmJpbmFyeU9wZXJhdGUoY2FsLmtleUNvZGVzW2tleUNvZGVdLCBjYWwub3BlcmF0b3JGYWNhZGVba2V5Q29kZV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMjpcclxuICAgICAgICAgICAgICAgICAgICBjYWwuY2FsY3VsYXRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAvL2NlXHJcbiAgICAgICAgICAgICAgICBjYXNlIDM3OlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC5jZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy9jXHJcbiAgICAgICAgICAgICAgICBjYXNlIDM4OlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC5jbGVhcigpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy9iYWNrXHJcbiAgICAgICAgICAgICAgICBjYXNlIDM5OlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC5iYWNrKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAvLyAoXHJcbiAgICAgICAgICAgICAgICBjYXNlIDIxOlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC5zZXRQcmVTdGVwKGNhbC5nZXRQcmVTdGVwKCkgKyBcIiAoXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIG1fY2FsLm9wZXJhdG9yU3RhY2sucHVzaChcIihcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAvLyApXHJcbiAgICAgICAgICAgICAgICBjYXNlIDIyOlxyXG4gICAgICAgICAgICAgICAgICAgIGNhbC5yaWdodFRhZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgLy/lkJHkuIrnrq3lpLTvvIzmiorkuIrmrKHorqHnrpfnu5PmnpzmmL7npLrlh7rmnaVcclxuICAgICAgICAgICAgICAgIGNhc2UgMzY6XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLnNldFNob3dJbnB1dChtX2NhbC5wcmVSZXN1bHQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICog5omn6KGM5LiA5YWD6L+Q566XIOavlOWmguWPluWAkuaVsOOAgeW5s+aWuVxyXG4gICAgICogQHBhcmFtIG9wZXJhdGlvbiDlhbfkvZPov5Dnrpflm57osIPlh73mlbBcclxuICAgICAqIOS8muWQkW9wZXJhdGlvbuS8oOmAkuS4gOS4quWPguaVsHNp77yM5Li655So5oi35b2T5YmN55qE6L6T5YWl77yM5ZCM5pe2b3BlcmF0aW9u5Ye95pWw5bqU6K+l6L+U5Zue5LiA5Liq5pWw57uE77yM5pWw57uE55qE56ys5LiA5LiqXHJcbiAgICAgKiDlhYPntKDmmK/orqHnrpfnmoTnu5PmnpzvvIznrKzkuozkuKrlhYPntKDnpLrkvotzcXJ077yM56ys5LqM5Liq5Y+C5pWw5Y+v6YCJXHJcbiAgICAgKi9cclxuICAgIHVuYXJ5T3BlcmF0ZTogZnVuY3Rpb24gKG9wZXJhdGlvbikge1xyXG4gICAgICAgIGxldCBzaSA9IGNhbC5nZXRTaG93SW5wdXQoKSxcclxuICAgICAgICAgICAgcmVzdWx0O1xyXG4gICAgICAgIGlmIChjYWwuaXNJbnRlZ2VyKHNpKSkge1xyXG4gICAgICAgICAgICByZXN1bHQgPSBvcGVyYXRpb24ocGFyc2VJbnQoc2kpKTtcclxuICAgICAgICB9IGVsc2UgaWYgKGNhbC5pc0Zsb2F0KHNpKSB8fCBjYWwuaXNTY2llbnRpZmljKHNpKSkge1xyXG4gICAgICAgICAgICByZXN1bHQgPSBvcGVyYXRpb24ocGFyc2VGbG9hdChzaSkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocmVzdWx0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgY2FsLnNldFNob3dJbnB1dChjYWwuY2hlY2tMZW5ndGgocmVzdWx0WzBdKSk7XHJcbiAgICAgICAgICAgIGlmIChyZXN1bHQubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICAgICAgLy/mmL7npLpwcmVzdGVw5pyJ5Lik56eN5oOF5Ya1OlxyXG4gICAgICAgICAgICAgICAgLy/nrKzkuIDnp43lsLHmmK/ov5nmmK/nrKzkuIDmrKEo5oyH6L+e57ut6LCD55So55qE56ys5LiA5qyhKeiwg+eUqOS4gOWFg+WHveaVsO+8jOatpOaXtuebtOaOpeaOpeWcqOacq+WwvuWNs+WPr1xyXG4gICAgICAgICAgICAgICAgaWYgKCFtX2NhbC5pc1ByZUlucHV0VW5hcnlPcGVyYXRvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhbC5zZXRQcmVTdGVwKGNhbC5nZXRQcmVTdGVwKCkgKyBcIiBcIiArIHJlc3VsdFsxXSArIFwiKFwiICsgc2kgKyBcIilcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgbV9jYWwuaXNQcmVJbnB1dFVuYXJ5T3BlcmF0b3IgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAvL+esrOS6jOenjeWwseaYr+i/meS4jeaYr+esrOS4gOasoe+8jOmCo+S5iOW6lOivpeaIquWPluacgOWQjuS4gOS4quepuuagvOS5i+WQjueahOWGheWuuei/m+ihjOabv+aNolxyXG4gICAgICAgICAgICAgICAgICAgIC8v5q+U5aaCMSArIDMgKyBzcXJ0KDEwMCnvvIzpgqPkuYjlupTor6Xku47mnIDlkI7kuIDkuKrnqbrmoLzlkI7mm7/mjaLkuLrmraTmrKHmk43kvZznmoTlhoXlrrlcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcGkgPSBjYWwuZ2V0UHJlU3RlcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHBpID0gcGkuc3Vic3RyaW5nKDAsIHBpLmxhc3RJbmRleE9mKFwiIFwiKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcGkgKz0gKFwiIFwiICsgcmVzdWx0WzFdICsgXCIoXCIgKyBzaSArIFwiKVwiKTtcclxuICAgICAgICAgICAgICAgICAgICBjYWwuc2V0UHJlU3RlcChwaSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy/kuIDlhYPov5Dnrpfnu5PmnZ/lkI7lupTor6Xopobnm5ZcclxuICAgICAgICAgICAgbV9jYWwuaXNPdmVycmlkZSA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1fY2FsLmlzUHJlSW5wdXRCaW5hcnlPcGVyYXRvciA9IGZhbHNlO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICog5LqM5YWD5pON5L2cKCsgLSAqIC8gJSlcclxuICAgICAqIEBwYXJhbSBvcGVyYXRvciDmk43kvZznrKZcclxuICAgICAqIEBwYXJhbSBmYWNhZGUg6L+Q566X56ym6Zeo6Z2i77yM55So5LqO5pi+56S65ZyocHJlU3RlcOS4rVxyXG4gICAgICovXHJcbiAgICBiaW5hcnlPcGVyYXRlOiBmdW5jdGlvbiAob3BlcmF0b3IsIGZhY2FkZSkge1xyXG4gICAgICAgIC8v5aaC5p6c5piv56iL5bqP5ZGY5Z6L77yM6YKj5LmI6ZyA6KaB6YeN572uc2NhbGVzU3BhblxyXG4gICAgICAgIGlmIChjYWwudHlwZSA9PT0gMykge1xyXG4gICAgICAgICAgICBjYWwucmVzZXRTY2FsZXMoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHNpID0gY2FsLmdldFNob3dJbnB1dCgpLFxyXG4gICAgICAgICAgICBwaSA9IGNhbC5nZXRQcmVTdGVwKCk7XHJcbiAgICAgICAgaWYgKGNhbC5pc051bWJlcihzaSkpIHtcclxuICAgICAgICAgICAgLy/ljovmk43kvZzmlbDmoIhcclxuICAgICAgICAgICAgbV9jYWwub3BlcmFuZFN0YWNrLnB1c2goc2kpO1xyXG4gICAgICAgICAgICAvL+iuvue9rnByZVN0ZXDmnInkuInnp43mg4XlhrU656ys5LiA56eN5LiK5LiA5q2l5LiN5piv5LiA5YWD5pON5L2c77yM6YKj5LmI6ZyA6KaB6K6+572uc2nvvIznrKzkuoznp43mmK/kuIDlhYPmk43kvZzvvIzpgqPkuYjnlLHkuo7kuIDlhYPmk43kvZzkvJrmiopcclxuICAgICAgICAgICAgLy/lh73mlbDooajovr7lvI8o5q+U5aaCc3FydCgxMDApKeiuvue9ruWIsHByZVN0ZXDvvIzmiYDku6XkuI3pnIDopoHlho3mrKHorr7nva5zaVxyXG4gICAgICAgICAgICAvL+esrOS4ieenjeWwseaYr+WmguaenOacgOWQjuS4gOS9jeaYr+WPs+aLrOWPt++8jOmCo+S5iOS5n+S4jemcgOimgeiuvue9rnNpXHJcbiAgICAgICAgICAgIGNhbC5zZXRQcmVTdGVwKGNhbC5nZXRQcmVTdGVwKCkgKyAoKG1fY2FsLmlzUHJlSW5wdXRVbmFyeU9wZXJhdG9yIHx8IHBpLmNoYXJBdChwaS5sZW5ndGggLSAxKSA9PT0gXCIpXCIpID9cclxuICAgICAgICAgICAgICAgIChcIiBcIiArIGZhY2FkZSkgOiAoXCIgXCIgKyBzaSArIFwiIFwiICsgZmFjYWRlKSkpO1xyXG4gICAgICAgICAgICBsZXQgcHJlT3AgPSBtX2NhbC5vcGVyYXRvclN0YWNrLnBvcCgpO1xyXG4gICAgICAgICAgICBpZiAocHJlT3AgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IG9wID0gY2FsLm9wZXJhdG9yUHJpb3JpdHlbb3BlcmF0b3JdLFxyXG4gICAgICAgICAgICAgICAgICAgIHBwID0gY2FsLm9wZXJhdG9yUHJpb3JpdHlbcHJlT3BdO1xyXG4gICAgICAgICAgICAgICAgLy/lpoLmnpzlvZPliY3ov5DnrpfnrKbkvJjlhYjnuqfmm7Tpq5jvvIzpgqPkuYjlj6rpnIDljovmoIjkuI3pnIDopoHorqHnrpdcclxuICAgICAgICAgICAgICAgIGlmIChvcCA+IHBwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbV9jYWwub3BlcmF0b3JTdGFjay5wdXNoKHByZU9wKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8v5Lik6ICF55qE5LyY5YWI57qn55u4562J5bm25LiU6auY5LqOMyjliqDlh48p77yM6YKj5LmI5Y+q6ZyA6KaB6K6h566X5LiA5q2lXHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChvcCA+IDMgJiYgb3AgPT09IHBwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbV9jYWwub3BlcmF0b3JTdGFjay5wdXNoKHByZU9wKTtcclxuICAgICAgICAgICAgICAgICAgICBjYWwudHJhdmVsU3RhY2soMSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIG1fY2FsLm9wZXJhdG9yU3RhY2sucHVzaChwcmVPcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsLnNldFNob3dJbnB1dChjYWwuY2hlY2tMZW5ndGgoY2FsLnRyYXZlbFN0YWNrKG51bGwsIG9wKSkpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG1fY2FsLm9wZXJhdG9yU3RhY2sucHVzaChvcGVyYXRvcik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1fY2FsLmlzUHJlSW5wdXRVbmFyeU9wZXJhdG9yID0gZmFsc2U7XHJcbiAgICAgICAgbV9jYWwuaXNQcmVJbnB1dEVxdWFscyA9IGZhbHNlO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICog5oyJ5LiLPeaXtuiuoeeul+acgOe7iOe7k+aenFxyXG4gICAgICovXHJcbiAgICBjYWxjdWxhdGU6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBpZiAoIW1fY2FsLmlzUHJlSW5wdXRFcXVhbHMpIHtcclxuICAgICAgICAgICAgbGV0IHNpID0gY2FsLmdldFNob3dJbnB1dCgpLFxyXG4gICAgICAgICAgICAgICAgcmVzdWx0O1xyXG4gICAgICAgICAgICBpZiAoY2FsLmlzTnVtYmVyKHNpKSkge1xyXG4gICAgICAgICAgICAgICAgbV9jYWwub3BlcmFuZFN0YWNrLnB1c2goc2kpO1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gY2FsLmNoZWNrTGVuZ3RoKGNhbC50cmF2ZWxTdGFjaygpKTtcclxuICAgICAgICAgICAgICAgIGNhbC5zZXRTaG93SW5wdXQocmVzdWx0KTtcclxuICAgICAgICAgICAgICAgIG1fY2FsLnByZVJlc3VsdCA9IHJlc3VsdDtcclxuICAgICAgICAgICAgICAgIGNhbC5zZXRQcmVTdGVwKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgLy/nqIvluo/lkZjlnovpnIDopoHmiororqHnrpfnu5PmnpznmoTlm5vnp43ov5vliLblgLzmmL7npLrlh7rmnaVcclxuICAgICAgICAgICAgICAgIGlmIChjYWwudHlwZSA9PT0gMykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhbC5zaG93U2NhbGVzKHJlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBtX2NhbC5pc092ZXJyaWRlID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjYWwuX3Jlc2V0KCk7XHJcbiAgICAgICAgICAgIG1fY2FsLmlzUHJlSW5wdXRFcXVhbHMgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOiuv+mXrui/kOeul+agiO+8jOi/lOWbnuiuoeeul+e7k+aenFxyXG4gICAgICogQHBhcmFtIGxldmVsIOiuoeeul+eahOWxguaVsO+8jOWmguaenOS4jeaMh+Wumu+8jOmCo+S5iOmBjeWOhuaVtOS4quagiFxyXG4gICAgICogQHBhcmFtIG1pblByaSjmnIDlsI8v5oiq5q2i5LyY5YWI57qnKSDmraTlj4LmlbDpkojlr7nkuIvpnaLnmoTmg4XlhrU6XHJcbiAgICAgKiAyICsgMiBYIDMgWCAyIF4gMiBYIDLvvIznlLHkuo7mnIDlkI7kuIDkuKrov5DnrpfnrKbmmK9Y77yM5LyY5YWI57qn5q+UXuS9ju+8jOaJgOS7peinpuWPkeS6huWvueaTjeS9nOagiOeahOmBjeWOhu+8jOS9huaYr+S4jeiDveWFqOmDqOmBjeWOhu+8jOW6lOivpemBjeWOhuWIsOesrOS4gOS4qljlgZzmraJcclxuICAgICAqIOWmguaenOS4jeWBnOatouW+l+WIsOeahOWwhuaYr+mUmeivr+eahDI2IFggMiA9IDUy77yM5q2j56Gu57uT5p6c5pivMiArIDI0IFggMiA9IDUwXHJcbiAgICAgKiBAcmV0dXJuIE51bWJlclxyXG4gICAgICogQHByaXZhdGVcclxuICAgICAqL1xyXG4gICAgdHJhdmVsU3RhY2s6IGZ1bmN0aW9uIChsZXZlbCwgbWluUHJpKSB7XHJcbiAgICAgICAgbGV0IG9wLCBmLCBzLFxyXG4gICAgICAgICAgICAvL3Jlc3VsdOWPluaTjeS9nOaVsOagiOagiOmhtu+8jOWboOS4uumYsuatouWcqOS4i+WIl+aDheWGtTkgWCAoNiArIOaXtuWHuueOsHVuZGVmaW5lZFxyXG4gICAgICAgICAgICByZXN1bHQgPSBtX2NhbC5vcGVyYW5kU3RhY2tbbV9jYWwub3BlcmFuZFN0YWNrLmxlbmd0aCAtIDFdLFxyXG4gICAgICAgICAgICBsID0gbGV2ZWwgfHwgbV9jYWwub3BlcmF0b3JTdGFjay5sZW5ndGgsXHJcbiAgICAgICAgICAgIHAgPSBtaW5QcmkgfHwgMDtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGw7ICsraSkge1xyXG4gICAgICAgICAgICBvcCA9IG1fY2FsLm9wZXJhdG9yU3RhY2sucG9wKCk7XHJcbiAgICAgICAgICAgIC8v6YGH5YiwbWluUHJp5oiW5bem5ous5Y+356uL5Y2z5YGc5q2i77yM5bem5ous5Y+35Lmf6ZyA6KaB5YaN5qyh5Y6L5YWl77yM5Zug5Li65Y+q5pyJ5LiA5Liq5Y+z5ous5Y+35omN6IO95oq15raI5LiA5Liq5bem5ous5Y+3XHJcbiAgICAgICAgICAgIGlmIChjYWwub3BlcmF0b3JQcmlvcml0eVtvcF0gPCBwIHx8IG9wID09PSBcIihcIikge1xyXG4gICAgICAgICAgICAgICAgbV9jYWwub3BlcmF0b3JTdGFjay5wdXNoKG9wKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHMgPSBtX2NhbC5vcGVyYW5kU3RhY2sucG9wKCk7XHJcbiAgICAgICAgICAgIGYgPSBtX2NhbC5vcGVyYW5kU3RhY2sucG9wKCk7XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IGNhbC5fc3RhY2tIZWxwZXIoZiwgcywgb3ApO1xyXG4gICAgICAgICAgICBtX2NhbC5vcGVyYW5kU3RhY2sucHVzaChyZXN1bHQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICog6L6T5YWl5LqG5LiA5Liq5Y+z5ous5Y+3XHJcbiAgICAgKi9cclxuICAgIHJpZ2h0VGFnOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgbGV0IHNpID0gY2FsLmdldFNob3dJbnB1dCgpO1xyXG4gICAgICAgIGlmIChjYWwuaXNOdW1iZXIoc2kpKSB7XHJcbiAgICAgICAgICAgIGNhbC5zZXRQcmVTdGVwKGNhbC5nZXRQcmVTdGVwKCkgKyAoXCIgXCIgKyBzaSArIFwiIClcIikpO1xyXG4gICAgICAgICAgICBtX2NhbC5vcGVyYW5kU3RhY2sucHVzaChzaSk7XHJcbiAgICAgICAgICAgIC8v6YGN5Y6G6K6h566X5pON5L2c5qCI77yM55u06Iez6YGH5Yiw5bem5ous5Y+3XHJcbiAgICAgICAgICAgIGxldCBvcCA9IG1fY2FsLm9wZXJhdG9yU3RhY2sucG9wKCksXHJcbiAgICAgICAgICAgICAgICBmLCBzLCByZXN1bHQ7XHJcbiAgICAgICAgICAgIHdoaWxlIChvcCAhPT0gXCIoXCIgJiYgb3AgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgcyA9IG1fY2FsLm9wZXJhbmRTdGFjay5wb3AoKTtcclxuICAgICAgICAgICAgICAgIGYgPSBtX2NhbC5vcGVyYW5kU3RhY2sucG9wKCk7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQgPSBjYWwuX3N0YWNrSGVscGVyKGYsIHMsIG9wKTtcclxuICAgICAgICAgICAgICAgIG1fY2FsLm9wZXJhbmRTdGFjay5wdXNoKHJlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICBvcCA9IG1fY2FsLm9wZXJhdG9yU3RhY2sucG9wKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy/mraTlpITlupTor6Xnm7TmjqXmiorlsI/mi6zlj7fnmoTorqHnrpflhoXlrrnlvLnlh7rvvIzlm6DkuLrmraTnu5PmnpzmmL7npLrlnKjkuoZzaG93SW5wdXTkuK3vvIzogIzlho3mrKHmiafooYzkuozlhYPmk43kvZzml7bkvJrlhYjmnInkuIDkuKrljovmoIjnmoTmk43kvZzvvIxcclxuICAgICAgICAgICAgLy8g5bm25LiU5omn6KGMPeaXtuS5n+aYr+agueaNrnNob3dJbnB1dOWGheWuueiuoeeul+eahFxyXG4gICAgICAgICAgICBjYWwuc2V0U2hvd0lucHV0KGNhbC5jaGVja0xlbmd0aChtX2NhbC5vcGVyYW5kU3RhY2sucG9wKCkpKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiDovoXliqnov5vooYzkuIDmrKHmoIjov5DnrpdcclxuICAgICAqIEBwYXJhbSBmIOesrOS4gOS4quaTjeS9nOaVsFxyXG4gICAgICogQHBhcmFtIHMg56ys5LqM5Liq5pON5L2c5pWwXHJcbiAgICAgKiBAcGFyYW0gb3Ag6L+Q566X56ymXHJcbiAgICAgKiBAcmV0dXJuIOi/lOWbnui/kOeul+e7k+aenFxyXG4gICAgICogQHByaXZhdGVcclxuICAgICAqL1xyXG4gICAgX3N0YWNrSGVscGVyOiBmdW5jdGlvbiAoZiwgcywgb3ApIHtcclxuICAgICAgICBsZXQgcmVzdWx0O1xyXG4gICAgICAgIGlmIChvcCA9PT0gXCJeXCIpIHtcclxuICAgICAgICAgICAgcmVzdWx0ID0gTWF0aC5wb3coZiwgcyk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChvcCA9PT0gXCJ5cm9vdFwiKSB7XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IE1hdGgucG93KGYsIDEgLyBzKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8rIC0gWCAvICU15Lit5pON5L2cXHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIC8v5aaC5p6c5piv56iL5bqP5ZGY5Z6L77yM6YKj5LmI6ZyA6KaB6ICD6JmR6L+b5Yi255qE6Zeu6aKYXHJcbiAgICAgICAgICAgIGlmIChjYWwudHlwZSA9PT0gMykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHNjYWxlID0gbV9jYWwuY3VycmVudFNjYWxlLFxyXG4gICAgICAgICAgICAgICAgICAgIGZpLCBzaTtcclxuICAgICAgICAgICAgICAgIGlmIChzY2FsZSA9PT0gMTApIHtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBldmFsKGYgKyBvcCArIHMpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChzY2FsZSA9PT0gMTYpIHtcclxuICAgICAgICAgICAgICAgICAgICBmaSA9IHBhcnNlSW50KGYsIDE2KTtcclxuICAgICAgICAgICAgICAgICAgICBzaSA9IHBhcnNlSW50KHMsIDE2KTtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBldmFsKGZpICsgb3AgKyBzaSkudG9TdHJpbmcoMTYpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChzY2FsZSA9PT0gOCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpID0gcGFyc2VJbnQoZiwgOCk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2kgPSBwYXJzZUludChzLCA4KTtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBldmFsKGZpICsgb3AgKyBzaSkudG9TdHJpbmcoOCk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpID0gcGFyc2VJbnQoZiwgMik7XHJcbiAgICAgICAgICAgICAgICAgICAgc2kgPSBwYXJzZUludChzLCAyKTtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBldmFsKGZpICsgb3AgKyBzaSkudG9TdHJpbmcoMik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQgPSBldmFsKGYgKyBvcCArIHMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiDnoa7kv53nu5Pmnpzplb/luqbkuI3lpKfkuo4xMyzlpoLmnpzotoXlh7rvvIzku6Xnp5HlraborqHmlbDms5XlvaLlvI/mmL7npLoo5bCP5pWw54K55ZCON+S9jSlcclxuICAgICAqIEBwYXJhbSB2YWx1ZSDpnIDopoHmo4Dmn6XnmoTnu5PmnpxcclxuICAgICAqL1xyXG4gICAgY2hlY2tMZW5ndGg6IGZ1bmN0aW9uICh2YWx1ZSkge1xyXG4gICAgICAgIGxldCB2YWx1ZVN0ciA9IHZhbHVlICsgXCJcIjtcclxuICAgICAgICBpZiAoY2FsLmlzRmxvYXQodmFsdWVTdHIpKSB7XHJcbiAgICAgICAgICAgIHZhbHVlU3RyID0gdmFsdWVTdHIucmVwbGFjZSgvMCskLywgXCJcIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB2YWx1ZVN0ci5sZW5ndGggPiAxMiA/IHZhbHVlLnRvRXhwb25lbnRpYWwoNykgOiB2YWx1ZVN0cjtcclxuICAgIH0sXHJcbiAgICAvL0NFXHJcbiAgICBjZTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNhbC5zZXRTaG93SW5wdXQoXCIwXCIpO1xyXG4gICAgICAgIGlmIChjYWwudHlwZSA9PT0gMykge1xyXG4gICAgICAgICAgICBjYWwucmVzZXRTY2FsZXMoKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy9DXHJcbiAgICBjbGVhcjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNhbC5zZXRTaG93SW5wdXQoXCIwXCIpO1xyXG4gICAgICAgIGNhbC5zZXRQcmVTdGVwKFwiXCIpO1xyXG4gICAgICAgIGNhbC5fcmVzZXQoKTtcclxuICAgICAgICBpZiAoY2FsLnR5cGUgPT09IDMpIHtcclxuICAgICAgICAgICAgY2FsLnJlc2V0U2NhbGVzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICog5riF56m65Zub5Liq6L+b5Yi255qE5YC8XHJcbiAgICAgKiBAcHJpdmF0ZVxyXG4gICAgICovXHJcbiAgICByZXNldFNjYWxlczogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNhbC5jYWNoZS5zY2FsZVNwYW5zW2ldLnN0cmluZyA9IFwiMFwiO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBiYWNrOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgbGV0IG9sZFZhbHVlID0gY2FsLmdldFNob3dJbnB1dCgpO1xyXG4gICAgICAgIGNhbC5zZXRTaG93SW5wdXQob2xkVmFsdWUubGVuZ3RoIDwgMiA/IFwiMFwiIDogb2xkVmFsdWUuc3Vic3RyaW5nKDAsIG9sZFZhbHVlLmxlbmd0aCAtIDEpKTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOW9k+iuoeeul+WZqOexu+Wei+aYr+eoi+W6j+WRmOaXtu+8jOmcgOimgeWQjOatpeaYvuekuuWbm+enjei/m+WItueahOWAvFxyXG4gICAgICogQHBhcmFtIG51bSDpnIDopoHmmL7npLrnmoTmlbDlrZdcclxuICAgICAqL1xyXG4gICAgc2hvd1NjYWxlczogZnVuY3Rpb24gKG51bSkge1xyXG4gICAgICAgIGxldCByZXN1bHQgPSBjYWwuY2FsY3VsYXRlU2NhbGVzKG51bSksXHJcbiAgICAgICAgICAgIHNwYW5zID0gY2FsLmNhY2hlLnNjYWxlU3BhbnM7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA0OyArK2kpIHtcclxuICAgICAgICAgICAgc3BhbnNbaV0uc3RyaW5nID0gcmVzdWx0W2ldO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOagueaNruW9k+WJjei/m+WItuWIhuWIq+iuoeeul+WHuuWbm+enjei/m+WItueahOWAvFxyXG4gICAgICogQHBhcmFtIG51bSDpnIDopoHorqHnrpfnmoTlgLxcclxuICAgICAqIEByZXR1cm4gQXJyYXkg5YWxNOS4quWFg+e0oO+8jOS+neasoeS4ujE244CBMTDjgIE444CBMui/m+WItueahOWAvFxyXG4gICAgICovXHJcbiAgICBjYWxjdWxhdGVTY2FsZXM6IGZ1bmN0aW9uIChudW0pIHtcclxuICAgICAgICBsZXQgc2NhbGUgPSBtX2NhbC5jdXJyZW50U2NhbGUsXHJcbiAgICAgICAgICAgIHJlc3VsdCA9IFtdLFxyXG4gICAgICAgICAgICBpO1xyXG4gICAgICAgIGlmIChzY2FsZSA9PT0gMTApIHtcclxuICAgICAgICAgICAgaSA9IHBhcnNlSW50KG51bSk7XHJcbiAgICAgICAgICAgIHJlc3VsdFswXSA9IGkudG9TdHJpbmcoMTYpO1xyXG4gICAgICAgICAgICByZXN1bHRbMV0gPSBpO1xyXG4gICAgICAgICAgICByZXN1bHRbMl0gPSBpLnRvU3RyaW5nKDgpO1xyXG4gICAgICAgICAgICByZXN1bHRbM10gPSBpLnRvU3RyaW5nKDIpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoc2NhbGUgPT09IDE2KSB7XHJcbiAgICAgICAgICAgIC8v5YWI6L2s5oiQMTDov5vliLbvvIznhLblkI7lho3ovazmiJDlhbblroPov5vliLZcclxuICAgICAgICAgICAgaSA9IHBhcnNlSW50KG51bSwgMTYpO1xyXG4gICAgICAgICAgICByZXN1bHRbMF0gPSBudW07XHJcbiAgICAgICAgICAgIHJlc3VsdFsxXSA9IGk7XHJcbiAgICAgICAgICAgIHJlc3VsdFsyXSA9IGkudG9TdHJpbmcoOCk7XHJcbiAgICAgICAgICAgIHJlc3VsdFszXSA9IGkudG9TdHJpbmcoMik7XHJcbiAgICAgICAgfSBlbHNlIGlmIChzY2FsZSA9PT0gOCkge1xyXG4gICAgICAgICAgICBpID0gcGFyc2VJbnQobnVtLCA4KTtcclxuICAgICAgICAgICAgcmVzdWx0WzBdID0gaS50b1N0cmluZygxNik7XHJcbiAgICAgICAgICAgIHJlc3VsdFsxXSA9IGk7XHJcbiAgICAgICAgICAgIHJlc3VsdFsyXSA9IG51bTtcclxuICAgICAgICAgICAgcmVzdWx0WzNdID0gaS50b1N0cmluZygyKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpID0gcGFyc2VJbnQobnVtLCAyKTtcclxuICAgICAgICAgICAgcmVzdWx0WzBdID0gaS50b1N0cmluZygxNik7XHJcbiAgICAgICAgICAgIHJlc3VsdFsxXSA9IGk7XHJcbiAgICAgICAgICAgIHJlc3VsdFsyXSA9IGkudG9TdHJpbmcoOCk7XHJcbiAgICAgICAgICAgIHJlc3VsdFszXSA9IG51bTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOagoemqjOWtl+espuS4suaYr+WQpuaYr+aVsOWtl1xyXG4gICAgICogQHBhcmFtIHN0clxyXG4gICAgICogQHJldHVybiDmmK/ov5Tlm550cnVlXHJcbiAgICAgKi9cclxuICAgIGlzTnVtYmVyOiBmdW5jdGlvbiAoc3RyKSB7XHJcbiAgICAgICAgcmV0dXJuIGNhbC5pc0ludGVnZXIoc3RyKSB8fCBjYWwuaXNGbG9hdChzdHIpIHx8IGNhbC5pc1NjaWVudGlmaWMoc3RyKSB8fCBjYWwuaXNIZXgoc3RyKTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOagoemqjOaYr+WQpuaYr+aVtOaVsFxyXG4gICAgICogQHBhcmFtIHN0clxyXG4gICAgICovXHJcbiAgICBpc0ludGVnZXI6IGZ1bmN0aW9uIChzdHIpIHtcclxuICAgICAgICByZXR1cm4gc3RyLm1hdGNoKGNhbC5pbnRQYXR0ZXJuKTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOagoemqjOaYr+WQpuaYr+Wwj+aVsFxyXG4gICAgICogQHBhcmFtIHN0clxyXG4gICAgICovXHJcbiAgICBpc0Zsb2F0OiBmdW5jdGlvbiAoc3RyKSB7XHJcbiAgICAgICAgcmV0dXJuIHN0ci5tYXRjaChjYWwuZmxvYXRQYXR0ZXJuKTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOaYr+WQpuaYr+enkeWtpuiuoeaVsOazlVxyXG4gICAgICogQHBhcmFtIHN0clxyXG4gICAgICovXHJcbiAgICBpc1NjaWVudGlmaWM6IGZ1bmN0aW9uIChzdHIpIHtcclxuICAgICAgICByZXR1cm4gc3RyLm1hdGNoKGNhbC5zY2llbnRpZmljUGF0dGVybik7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiDmmK/lkKbmmK8xNui/m+WItuaVsOWtl1xyXG4gICAgICogQHBhcmFtIHN0clxyXG4gICAgICovXHJcbiAgICBpc0hleDogZnVuY3Rpb24gKHN0cikge1xyXG4gICAgICAgIHJldHVybiBzdHIubWF0Y2goY2FsLmhleFBhdHRlcm4pO1xyXG4gICAgfSxcclxuICAgIC8qKlxyXG4gICAgICog5pi+56S66L6T5YWl55qE5YaF5a65XHJcbiAgICAgKiDnlKjkuo7nm7jlupTmlbDlrZcv5bCP5pWw54K55oyJ6ZSuXHJcbiAgICAgKiBAcGFyYW0gdmFsdWUg5oyJ6ZSu55qE5YaF5a6577yM5LiN5piva2V5Q29kZVxyXG4gICAgICovXHJcbiAgICBzaG93SW5wdXQ6IGZ1bmN0aW9uICh2YWx1ZSkge1xyXG4gICAgICAgIGxldCBvbGRWYWx1ZSA9IGNhbC5nZXRTaG93SW5wdXQoKTtcclxuICAgICAgICBsZXQgbmV3VmFsdWUgPSBvbGRWYWx1ZTtcclxuICAgICAgICBpZiAobV9jYWwuaXNPdmVycmlkZSkge1xyXG4gICAgICAgICAgICAvL+aXoueEtuaYr+imhueblu+8jOmCo+S5iOWmguaenOebtOaOpei+k+WFpS7pgqPkuYjogq/lrprmmK8wLnhcclxuICAgICAgICAgICAgaWYgKHZhbHVlID09PSBcIi5cIikge1xyXG4gICAgICAgICAgICAgICAgbmV3VmFsdWUgPSBcIjAuXCI7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBuZXdWYWx1ZSA9IHZhbHVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmIChvbGRWYWx1ZS5sZW5ndGggPCAxMykge1xyXG4gICAgICAgICAgICBpZiAob2xkVmFsdWUgPT09IFwiMFwiKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodmFsdWUgPT09IFwiLlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3VmFsdWUgPSBcIjAuXCI7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIG5ld1ZhbHVlID0gdmFsdWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBuZXdWYWx1ZSArPSB2YWx1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBjYWwuc2V0U2hvd0lucHV0KG5ld1ZhbHVlKTtcclxuICAgICAgICBtX2NhbC5pc092ZXJyaWRlID0gZmFsc2U7XHJcbiAgICAgICAgbV9jYWwuaXNQcmVJbnB1dEJpbmFyeU9wZXJhdG9yID0gZmFsc2U7XHJcbiAgICAgICAgbV9jYWwuaXNQcmVJbnB1dFVuYXJ5T3BlcmF0b3IgPSBmYWxzZTtcclxuICAgICAgICBtX2NhbC5pc1ByZUlucHV0RXF1YWxzID0gZmFsc2U7XHJcbiAgICB9LFxyXG4gICAgLyoqXHJcbiAgICAgKiDliIfmjaLorqHnrpflmajnsbvlnotcclxuICAgICAqIEBwYXJhbSB0eXBlIGludCDopoHliIfmjaLliLDnmoTnsbvlnotcclxuICAgICAqL1xyXG4gICAgc3dpdGNoVHlwZTogZnVuY3Rpb24gKHR5cGUpIHtcclxuICAgICAgICAvL+WFs+mXremAieaLqeagj1xyXG4gICAgICAgIGxldCBvbGRQcmVmaXggPSBjYWwudHlwZVByZWZpeFtjYWwudHlwZV07XHJcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQob2xkUHJlZml4ICsgXCJ0eXBlLWJhclwiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICAgICAgLy/liIfmjaLpnaLmnb9cclxuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChvbGRQcmVmaXggKyBcIm1haW5cIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xyXG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGNhbC50eXBlUHJlZml4W3R5cGVdICsgXCJtYWluXCIpLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XHJcbiAgICAgICAgY2FsLnR5cGUgPSB0eXBlO1xyXG4gICAgICAgIGlmICghY2FsLmhhc0luaXRlZFt0eXBlXSkge1xyXG4gICAgICAgICAgICBjYWwuaW5pdExpc3RlbmVycygpO1xyXG4gICAgICAgICAgICBjYWwuaGFzSW5pdGVkW3R5cGVdID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FsLmluaXRDYWNoZSgpO1xyXG4gICAgICAgIGNhbC5fcmVzZXQoKTtcclxuICAgIH0sXHJcbiAgICAvKipcclxuICAgICAqIOmHjee9ruWQhOS4quagh+W/l+WPmOmHj+S7peWPiuaTjeS9nOagiFxyXG4gICAgICogQHByaXZhdGVcclxuICAgICAqL1xyXG4gICAgX3Jlc2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgbV9jYWwub3BlcmFuZFN0YWNrID0gW107XHJcbiAgICAgICAgbV9jYWwub3BlcmF0b3JTdGFjayA9IFtdO1xyXG4gICAgICAgIG1fY2FsLmlzUHJlSW5wdXRCaW5hcnlPcGVyYXRvciA9IGZhbHNlO1xyXG4gICAgICAgIG1fY2FsLmlzUHJlSW5wdXRVbmFyeU9wZXJhdG9yID0gZmFsc2U7XHJcbiAgICAgICAgbV9jYWwuaXNQcmVJbnB1dEVxdWFscyA9IGZhbHNlO1xyXG4gICAgfSxcclxufSk7Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/FullScreenAdapter.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f91fcEAmNZDeoHbOcnMKaNq', 'FullScreenAdapter');
// Script/FullScreenAdapter.js

"use strict";

//FullScreenAdapter.js
cc.Class({
  "extends": cc.Component,
  properties: {
    bg: cc.Node
  },
  onLoad: function onLoad() {
    var _this = this;

    //监听窗口大小变化时的回调，每次窗口变化都要自动适配
    cc.view.setResizeCallback(function () {
      return _this.screenAdapter();
    });
    this.screenAdapter();
  },

  /**
   * Fit Height 模式：适用于宽大于高的屏幕
   * Fit Width 模式：适用于高大于宽的屏幕
   */
  screenAdapter: function screenAdapter() {
    //当前屏幕分辨率比例
    var screenRatio = cc.winSize.width / cc.winSize.height; //设计稿分辨率比例

    var designRatio = cc.Canvas.instance.designResolution.width / cc.Canvas.instance.designResolution.height;

    if (screenRatio <= 1) {
      //屏幕高度大于或等于宽度,即竖屏
      if (screenRatio <= designRatio) {
        this.setFitWidth();
      } else {
        //此时屏幕比例大于设计比例
        //为了保证纵向的游戏内容不受影响，应该使用 fitHeight 模式
        this.setFitHeight();
      }
    } else {
      //屏幕宽度大于高度,即横屏
      this.setFitHeight();
    }
  },
  setFitWidth: function setFitWidth() {
    cc.Canvas.instance.fitHeight = false;
    cc.Canvas.instance.fitWidth = true;
  },
  setFitHeight: function setFitHeight() {
    cc.Canvas.instance.fitHeight = true;
    cc.Canvas.instance.fitWidth = false;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxGdWxsU2NyZWVuQWRhcHRlci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImJnIiwiTm9kZSIsIm9uTG9hZCIsInZpZXciLCJzZXRSZXNpemVDYWxsYmFjayIsInNjcmVlbkFkYXB0ZXIiLCJzY3JlZW5SYXRpbyIsIndpblNpemUiLCJ3aWR0aCIsImhlaWdodCIsImRlc2lnblJhdGlvIiwiQ2FudmFzIiwiaW5zdGFuY2UiLCJkZXNpZ25SZXNvbHV0aW9uIiwic2V0Rml0V2lkdGgiLCJzZXRGaXRIZWlnaHQiLCJmaXRIZWlnaHQiLCJmaXRXaWR0aCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsRUFBRSxFQUFFSixFQUFFLENBQUNLO0FBREMsR0FIUDtBQU9MQyxFQUFBQSxNQVBLLG9CQU9LO0FBQUE7O0FBQ047QUFDQU4sSUFBQUEsRUFBRSxDQUFDTyxJQUFILENBQVFDLGlCQUFSLENBQTBCO0FBQUEsYUFBTSxLQUFJLENBQUNDLGFBQUwsRUFBTjtBQUFBLEtBQTFCO0FBQ0EsU0FBS0EsYUFBTDtBQUNILEdBWEk7O0FBYUw7QUFDSjtBQUNBO0FBQ0E7QUFDSUEsRUFBQUEsYUFqQkssMkJBaUJXO0FBQ1o7QUFDQSxRQUFJQyxXQUFXLEdBQUdWLEVBQUUsQ0FBQ1csT0FBSCxDQUFXQyxLQUFYLEdBQW1CWixFQUFFLENBQUNXLE9BQUgsQ0FBV0UsTUFBaEQsQ0FGWSxDQUdaOztBQUNBLFFBQUlDLFdBQVcsR0FBR2QsRUFBRSxDQUFDZSxNQUFILENBQVVDLFFBQVYsQ0FBbUJDLGdCQUFuQixDQUFvQ0wsS0FBcEMsR0FBNENaLEVBQUUsQ0FBQ2UsTUFBSCxDQUFVQyxRQUFWLENBQW1CQyxnQkFBbkIsQ0FBb0NKLE1BQWxHOztBQUVBLFFBQUlILFdBQVcsSUFBSSxDQUFuQixFQUFzQjtBQUNsQjtBQUNBLFVBQUlBLFdBQVcsSUFBSUksV0FBbkIsRUFBZ0M7QUFDNUIsYUFBS0ksV0FBTDtBQUNILE9BRkQsTUFFTztBQUNIO0FBQ0E7QUFDQSxhQUFLQyxZQUFMO0FBQ0g7QUFDSixLQVRELE1BU087QUFDSDtBQUNBLFdBQUtBLFlBQUw7QUFDSDtBQUNKLEdBcENJO0FBc0NMRCxFQUFBQSxXQXRDSyx5QkFzQ1M7QUFDVmxCLElBQUFBLEVBQUUsQ0FBQ2UsTUFBSCxDQUFVQyxRQUFWLENBQW1CSSxTQUFuQixHQUErQixLQUEvQjtBQUNBcEIsSUFBQUEsRUFBRSxDQUFDZSxNQUFILENBQVVDLFFBQVYsQ0FBbUJLLFFBQW5CLEdBQThCLElBQTlCO0FBQ0gsR0F6Q0k7QUEyQ0xGLEVBQUFBLFlBM0NLLDBCQTJDVTtBQUNYbkIsSUFBQUEsRUFBRSxDQUFDZSxNQUFILENBQVVDLFFBQVYsQ0FBbUJJLFNBQW5CLEdBQStCLElBQS9CO0FBQ0FwQixJQUFBQSxFQUFFLENBQUNlLE1BQUgsQ0FBVUMsUUFBVixDQUFtQkssUUFBbkIsR0FBOEIsS0FBOUI7QUFDSDtBQTlDSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL0Z1bGxTY3JlZW5BZGFwdGVyLmpzXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgYmc6IGNjLk5vZGVcclxuICAgIH0sXHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICAvL+ebkeWQrOeql+WPo+Wkp+Wwj+WPmOWMluaXtueahOWbnuiwg++8jOavj+asoeeql+WPo+WPmOWMlumDveimgeiHquWKqOmAgumFjVxyXG4gICAgICAgIGNjLnZpZXcuc2V0UmVzaXplQ2FsbGJhY2soKCkgPT4gdGhpcy5zY3JlZW5BZGFwdGVyKCkpO1xyXG4gICAgICAgIHRoaXMuc2NyZWVuQWRhcHRlcigpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvKipcclxuICAgICAqIEZpdCBIZWlnaHQg5qih5byP77ya6YCC55So5LqO5a695aSn5LqO6auY55qE5bGP5bmVXHJcbiAgICAgKiBGaXQgV2lkdGgg5qih5byP77ya6YCC55So5LqO6auY5aSn5LqO5a6955qE5bGP5bmVXHJcbiAgICAgKi9cclxuICAgIHNjcmVlbkFkYXB0ZXIoKSB7XHJcbiAgICAgICAgLy/lvZPliY3lsY/luZXliIbovqjnjofmr5TkvotcclxuICAgICAgICBsZXQgc2NyZWVuUmF0aW8gPSBjYy53aW5TaXplLndpZHRoIC8gY2Mud2luU2l6ZS5oZWlnaHQ7XHJcbiAgICAgICAgLy/orr7orqHnqL/liIbovqjnjofmr5TkvotcclxuICAgICAgICBsZXQgZGVzaWduUmF0aW8gPSBjYy5DYW52YXMuaW5zdGFuY2UuZGVzaWduUmVzb2x1dGlvbi53aWR0aCAvIGNjLkNhbnZhcy5pbnN0YW5jZS5kZXNpZ25SZXNvbHV0aW9uLmhlaWdodDtcclxuXHJcbiAgICAgICAgaWYgKHNjcmVlblJhdGlvIDw9IDEpIHtcclxuICAgICAgICAgICAgLy/lsY/luZXpq5jluqblpKfkuo7miJbnrYnkuo7lrr3luqYs5Y2z56uW5bGPXHJcbiAgICAgICAgICAgIGlmIChzY3JlZW5SYXRpbyA8PSBkZXNpZ25SYXRpbykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZXRGaXRXaWR0aCgpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy/mraTml7blsY/luZXmr5TkvovlpKfkuo7orr7orqHmr5TkvotcclxuICAgICAgICAgICAgICAgIC8v5Li65LqG5L+d6K+B57q15ZCR55qE5ri45oiP5YaF5a655LiN5Y+X5b2x5ZON77yM5bqU6K+l5L2/55SoIGZpdEhlaWdodCDmqKHlvI9cclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0Rml0SGVpZ2h0KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvL+Wxj+W5leWuveW6puWkp+S6jumrmOW6pizljbPmqKrlsY9cclxuICAgICAgICAgICAgdGhpcy5zZXRGaXRIZWlnaHQoKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHNldEZpdFdpZHRoKCkge1xyXG4gICAgICAgIGNjLkNhbnZhcy5pbnN0YW5jZS5maXRIZWlnaHQgPSBmYWxzZTtcclxuICAgICAgICBjYy5DYW52YXMuaW5zdGFuY2UuZml0V2lkdGggPSB0cnVlO1xyXG4gICAgfSxcclxuXHJcbiAgICBzZXRGaXRIZWlnaHQoKSB7XHJcbiAgICAgICAgY2MuQ2FudmFzLmluc3RhbmNlLmZpdEhlaWdodCA9IHRydWU7XHJcbiAgICAgICAgY2MuQ2FudmFzLmluc3RhbmNlLmZpdFdpZHRoID0gZmFsc2U7XHJcbiAgICB9XHJcbn0pOyJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Standard.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '64efcEa41pMeL6r2GxQ8w03', 'Standard');
// Script/Standard.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    lb_showInput: cc.Label,
    //输入
    lb_preStep: cc.Label //输出

  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var win = cc.director.getWinSize();
    cc.view.setDesignResolutionSize(win.width, win.height, cc.ResolutionPolicy.EXACT_FIT);
    window.std = this;
    this.lb_showInput.string = '0';
    this.lb_preStep.string = '';
  },
  start: function start() {},
  //按钮点击回调
  btnCallBack: function btnCallBack(sender, str) {
    cal.handleKey(str);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxTdGFuZGFyZC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImxiX3Nob3dJbnB1dCIsIkxhYmVsIiwibGJfcHJlU3RlcCIsIm9uTG9hZCIsIndpbiIsImRpcmVjdG9yIiwiZ2V0V2luU2l6ZSIsInZpZXciLCJzZXREZXNpZ25SZXNvbHV0aW9uU2l6ZSIsIndpZHRoIiwiaGVpZ2h0IiwiUmVzb2x1dGlvblBvbGljeSIsIkVYQUNUX0ZJVCIsIndpbmRvdyIsInN0ZCIsInN0cmluZyIsInN0YXJ0IiwiYnRuQ2FsbEJhY2siLCJzZW5kZXIiLCJzdHIiLCJjYWwiLCJoYW5kbGVLZXkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxZQUFZLEVBQUVKLEVBQUUsQ0FBQ0ssS0FEVDtBQUNpRDtBQUN6REMsSUFBQUEsVUFBVSxFQUFFTixFQUFFLENBQUNLLEtBRlAsQ0FFaUQ7O0FBRmpELEdBSFA7QUFRTDtBQUVBRSxFQUFBQSxNQVZLLG9CQVVLO0FBQ04sUUFBSUMsR0FBRyxHQUFHUixFQUFFLENBQUNTLFFBQUgsQ0FBWUMsVUFBWixFQUFWO0FBQ0FWLElBQUFBLEVBQUUsQ0FBQ1csSUFBSCxDQUFRQyx1QkFBUixDQUFnQ0osR0FBRyxDQUFDSyxLQUFwQyxFQUEyQ0wsR0FBRyxDQUFDTSxNQUEvQyxFQUF1RGQsRUFBRSxDQUFDZSxnQkFBSCxDQUFvQkMsU0FBM0U7QUFDQUMsSUFBQUEsTUFBTSxDQUFDQyxHQUFQLEdBQWEsSUFBYjtBQUNBLFNBQUtkLFlBQUwsQ0FBa0JlLE1BQWxCLEdBQTJCLEdBQTNCO0FBQ0EsU0FBS2IsVUFBTCxDQUFnQmEsTUFBaEIsR0FBeUIsRUFBekI7QUFDSCxHQWhCSTtBQWtCTEMsRUFBQUEsS0FsQkssbUJBa0JJLENBQ1IsQ0FuQkk7QUFxQkw7QUFDQUMsRUFBQUEsV0FBVyxFQUFDLHFCQUFTQyxNQUFULEVBQWdCQyxHQUFoQixFQUFvQjtBQUM1QkMsSUFBQUEsR0FBRyxDQUFDQyxTQUFKLENBQWNGLEdBQWQ7QUFDSCxHQXhCSSxDQTBCTDs7QUExQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBsYl9zaG93SW5wdXQ6IGNjLkxhYmVsLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL+i+k+WFpVxyXG4gICAgICAgIGxiX3ByZVN0ZXA6IGNjLkxhYmVsLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8v6L6T5Ye6XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgbGV0IHdpbiA9IGNjLmRpcmVjdG9yLmdldFdpblNpemUoKSA7XHJcbiAgICAgICAgY2Mudmlldy5zZXREZXNpZ25SZXNvbHV0aW9uU2l6ZSh3aW4ud2lkdGgsIHdpbi5oZWlnaHQsIGNjLlJlc29sdXRpb25Qb2xpY3kuRVhBQ1RfRklUKTtcclxuICAgICAgICB3aW5kb3cuc3RkID0gdGhpcztcclxuICAgICAgICB0aGlzLmxiX3Nob3dJbnB1dC5zdHJpbmcgPSAnMCc7XHJcbiAgICAgICAgdGhpcy5sYl9wcmVTdGVwLnN0cmluZyA9ICcnO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5oyJ6ZKu54K55Ye75Zue6LCDXHJcbiAgICBidG5DYWxsQmFjazpmdW5jdGlvbihzZW5kZXIsc3RyKXtcclxuICAgICAgICBjYWwuaGFuZGxlS2V5KHN0cilcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------
